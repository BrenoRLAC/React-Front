import React from "react";
import "./Frame34.css";

function Frame34(props) {
  const { cep, salvar } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-34 screen">
        <div className="flex-row-30">
          <div className="overlap-group1-21">
            <img className="line-73" src="/img/line-73@2x.svg" alt="Line 73" />
          </div>
          <div className="cep-1 balooda-regular-normal-cape-cod-48px">{cep}</div>
        </div>
        <img className="line-52-9" src="/img/line-52-10@1x.svg" alt="Line 52" />
        <div className="flex-row-31">
          <img className="line-69-1" src="/img/line-66@2x.svg" alt="Line 69" />
          <div className="overlap-group-37">
            <div className="salvar balooda2-normal-white-24px">{salvar}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame34;
