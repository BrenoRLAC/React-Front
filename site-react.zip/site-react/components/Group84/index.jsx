import React from "react";
import "./Group84.css";

function Group84(props) {
  const { className } = props;

  return (
    <div className={`group-84 ${className || ""}`}>
      <div className="overlap-group6-4">
        <div className="rectangle-161-5"></div>
        <div className="ellipse-54-6"></div>
        <div className="rectangle-162-6"></div>
        <img className="polygon-7-7" src="/img/polygon-7-7@2x.svg" alt="Polygon 7" />
      </div>
    </div>
  );
}

export default Group84;
