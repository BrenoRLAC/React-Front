import React from "react";
import { Link } from "react-router-dom";
import "./Frame18.css";

function Frame18(props) {
  const { rectangle191, skybank } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-18 screen" onclick="window.open('frame-1.html', '_self');">
        <div className="overlap-group-12">
          <img className="rectangle-191" src={rectangle191} alt="Rectangle 191" />
          <img className="sky-bank-3" src={skybank} alt="SkyBank" />
        </div>
      </div>
    </div>
  );
}

export default Frame18;
