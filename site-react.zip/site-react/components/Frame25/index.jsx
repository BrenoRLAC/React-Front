import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import Group24 from "../Group24";
import Group23 from "../Group23";
import Group87 from "../Group87";
import "./Frame25.css";

function Frame25(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    group53,
    rectangle199,
    skybank,
    conta,
    text13,
    depositar1,
    atividade,
    transferir,
    nomeDoUsuario,
    place,
    address,
    nmero,
    copiar,
    text14,
    validade,
    number,
    cvc,
    depositar2,
    qualValorVocQuer,
    depositar3,
    price,
    depositar4,
    group23Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-25 screen">
        <div className="overlap-group11-6">
          <div className="overlap-group13-6">
            <Group53 />
            <div className="ol-nome-do-usuario-7 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-24">
            <div className="overlap-group12-6">
              <div className="flex-row-26">
                <div className="rectangle-195-2"></div>
                <div className="overlap-group-33">
                  <div className="rectangle-46-7"></div>
                  <img className="line-9-7" src="/img/line-9-2@2x.svg" alt="Line 9" />
                  <div className="rectangle-47-7"></div>
                  <div className="rectangle-48-7"></div>
                  <img className="line-10-7" src="/img/line-10-7@2x.svg" alt="Line 10" />
                  <img className="line-11-7" src="/img/line-11-7@2x.svg" alt="Line 11" />
                </div>
                <div className="pgina-inicial-7 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-150">
                  <img className="config_icone-7" src="/img/config-icone-7@2x.svg" alt="Config_icone" />
                  <div className="configuraes-7 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-42-2" src="/img/line-37@2x.svg" alt="Line 42" />
              <img className="line-41-2" src="/img/line-37@2x.svg" alt="Line 41" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <img className="group-53-6" src={group53} alt="Group 53" />
              </a>
              <img className="line-43-3" src="/img/line-37@2x.svg" alt="Line 43" />
              <div className="flex-row-27">
                <img className="rectangle-199-2" src={rectangle199} alt="Rectangle 199" />
                <div className="sky-bank-8 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group14-4">
              <div className="overlap-group-container-25">
                <div className="overlap-group16-3">
                  <div className="overlap-group2-13">
                    <div className="flex-row-28">
                      <div className="group-container-8">
                        <div className="overlap-group3-11">
                          <div className="conta-6 balooda2-normal-cape-cod-36px">{conta}</div>
                          <div className="text-13 balooda-regular-normal-cape-cod-56px">{text13}</div>
                        </div>
                        <Group24 />
                      </div>
                      <div className="group-23-6">
                        <div className="overlap-group-34">
                          <div className="rectangle-161-10"></div>
                          <div className="ellipse-54-12"></div>
                          <div className="rectangle-162-12"></div>
                          <img className="polygon-7-13" src="/img/polygon-7-1@2x.svg" alt="Polygon 7" />
                        </div>
                      </div>
                    </div>
                    <div className="depositar-12">{depositar1}</div>
                  </div>
                  <img className="line-44-2" src="/img/line-61@1x.svg" alt="Line 44" />
                  <Link to="/frame-24">
                    <div className="group-57-3">
                      <div className="overlap-group7-8">
                        <img className="ellipse-13-3" src="/img/ellipse-13-3@2x.svg" alt="Ellipse 13" />
                        <img className="line-5-3" src="/img/line-5@2x.svg" alt="Line 5" />
                        <img className="line-7-3" src="/img/line-7@2x.svg" alt="Line 7" />
                        <img className="line-8-3" src="/img/line-8@2x.svg" alt="Line 8" />
                        <img className="line-6-3" src="/img/line-6@2x.svg" alt="Line 6" />
                      </div>
                    </div>
                  </Link>
                  <div className="atividade-6 balooda-regular-normal-cape-cod-20px">{atividade}</div>
                  <div className="transferir-12 balooda-regular-normal-cape-cod-20px">{transferir}</div>
                  <Group23 className={group23Props.className} />
                  <Link to="/frame-22">
                    <div className="group-127-1">
                      <div className="overlap-group9-7">
                        <div className="rectangle-163-17"></div>
                        <div className="ellipse-55-19"></div>
                        <div className="rectangle-164-19"></div>
                        <img className="polygon-8-19" src="/img/polygon-8-14@2x.svg" alt="Polygon 8" />
                      </div>
                    </div>
                  </Link>
                  <Link to="/frame-17">
                    <div className="group-128-1">
                      <Group87 />
                    </div>
                  </Link>
                </div>
                <div className="overlap-group15-4">
                  <Link to="/frame-21">
                    <div className="group-55-1">
                      <div className="overlap-group4-11">
                        <div className="overlap-group1-19">
                          <div className="nome-do-usuario-7 balooda2-bold-white-24px">{nomeDoUsuario}</div>
                          <div className="place-5 balooda2-normal-white-16px">{place}</div>
                        </div>
                        <div className="flex-row-29">
                          <div className="overlap-group5-8">
                            <div className="address-4 balooda2-bold-white-24px">{address}</div>
                            <div className="nmero-5 balooda2-normal-white-16px">{nmero}</div>
                          </div>
                          <div className="overlap-group6-6">
                            <div className="rectangle-175-4"></div>
                            <div className="line-container-3">
                              <img className="line-20-5" src="/img/line-20-2@2x.svg" alt="Line 20" />
                              <img className="line-21-3" src="/img/line-21@2x.svg" alt="Line 21" />
                            </div>
                          </div>
                          <div className="copiar-4 balooda2-bold-white-16px">{copiar}</div>
                          <Link to="/frame-26">
                            <img className="vector-18-6" src="/img/vector-18-2@2x.svg" alt="Vector 18" />
                          </Link>
                        </div>
                        <div className="overlap-group-container-26">
                          <div className="overlap-group-32">
                            <div className="text-14 balooda2-bold-white-20px">{text14}</div>
                            <div className="validade-4 balooda2-normal-white-16px">{validade}</div>
                          </div>
                          <div className="overlap-group-32">
                            <div className="number-4 balooda2-bold-white-20px">{number}</div>
                            <div className="cvc-4 balooda2-normal-white-16px">{cvc}</div>
                          </div>
                        </div>
                        <div className="rectangle-176-4"></div>
                      </div>
                    </div>
                  </Link>
                </div>
              </div>
              <div className="overlap-group-container-27">
                <div className="overlap-group2-14">
                  <div className="depositar-13 balooda2-normal-cape-cod-24px">{depositar2}</div>
                  <img className="line-2" src="/img/line-49@1x.svg" alt="Line 52" />
                  <img className="line-2" src="/img/line-49@1x.svg" alt="Line 65" />
                </div>
                <div className="overlap-group-35 balooda-regular-normal-cape-cod-56px">
                  <div className="qual-valor-voc-quer-2">{qualValorVocQuer}</div>
                  <div className="depositar-14">{depositar3}</div>
                </div>
                <div className="overlap-group3-12">
                  <div className="price-7 balooda-regular-normal-cape-cod-56px">{price}</div>
                  <img className="line-20-6" src="/img/line-20@2x.svg" alt="Line 20" />
                </div>
                <div className="overlap-group1-20">
                  <div className="depositar-15 balooda2-normal-white-24px">{depositar4}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame25;
