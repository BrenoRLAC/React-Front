import React from "react";
import { Link } from "react-router-dom";
import "./Frame4.css";

function Frame4(props) {
  const { endereo1, endereo2, nmero, complemento, place, uf, bairro, cep, voltar, group27, i } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-4 screen">
        <div className="overlap-group-container-3">
          <div className="flex-col">
            <div className="flex-col-1">
              <div className="endereo-1 balooda-regular-normal-cape-cod-36px">{endereo1}</div>
              <div className="overlap-group-container-4 balooda2-normal-silver-chalice-20px">
                <div className="overlap-group8-1">
                  <div className="endereo-2">{endereo2}</div>
                  <img className="rectangle-147" src="/img/rectangle-147@2x.svg" alt="Rectangle 147" />
                </div>
                <div className="overlap-group4-2">
                  <div className="nmero">{nmero}</div>
                  <img className="rectangle-148" src="/img/rectangle-148@2x.svg" alt="Rectangle 148" />
                </div>
                <div className="overlap-group6">
                  <div className="complemento">{complemento}</div>
                  <img className="rectangle-149" src="/img/rectangle-149@2x.svg" alt="Rectangle 149" />
                </div>
              </div>
            </div>
            <div className="overlap-group-container-5 balooda2-normal-silver-chalice-20px">
              <div className="overlap-group7-1">
                <div className="place">{place}</div>
                <img className="rectangle-15" src="/img/rectangle-152@2x.svg" alt="Rectangle 153" />
              </div>
              <div className="overlap-group2-1">
                <div className="uf">{uf}</div>
                <img className="rectangle-150" src="/img/rectangle-150@2x.svg" alt="Rectangle 150" />
                <img className="vector-18-1" src="/img/vector-18-1@2x.svg" alt="Vector 18" />
              </div>
              <div className="overlap-group5-2">
                <div className="bairro">{bairro}</div>
                <img className="rectangle-15" src="/img/rectangle-152@2x.svg" alt="Rectangle 152" />
              </div>
              <div className="overlap-group3-1">
                <div className="cep">{cep}</div>
                <img className="rectangle-146" src="/img/rectangle-146@2x.svg" alt="Rectangle 146" />
              </div>
            </div>
            <div className="group-container-1">
              <Link to="/frame-3">
                <div className="group-29">
                  <div className="overlap-group-3">
                    <div className="voltar balooda2-normal-white-24px-2">{voltar}</div>
                  </div>
                </div>
              </Link>
              <Link to="/frame-9">
                <img className="group-27" src={group27} alt="Group 27" />
              </Link>
            </div>
          </div>
          <div className="overlap-group9">
            <div className="ellipse-69"></div>
            <div className="i">{i}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame4;
