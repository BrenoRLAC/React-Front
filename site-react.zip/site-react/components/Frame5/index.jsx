import React from "react";
import { Link } from "react-router-dom";
import "./Frame5.css";

function Frame5(props) {
  const { desejaRealmenteDesconectar, no, sim } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-5 screen">
        <div className="deseja-realmente-desconectar balooda-regular-normal-cape-cod-36px">
          {desejaRealmenteDesconectar}
        </div>
        <img className="line-51" src="/img/line-51@1x.svg" alt="Line 51" />
        <div className="group-container-2">
          <div className="overlap-group-4">
            <div className="no balooda2-normal-white-24px-2">{no}</div>
          </div>
          <Link to="/frame-18">
            <div className="group-32">
              <div className="overlap-group1-2">
                <div className="sim balooda2-normal-white-24px">{sim}</div>
              </div>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Frame5;
