import React from "react";
import "./Group160.css";

function Group160(props) {
  const { className } = props;

  return (
    <div className={`group-160-1 ${className || ""}`}>
      <img className="group-15-1" src="/img/group-157-1@2x.svg" alt="Group 158" />
    </div>
  );
}

export default Group160;
