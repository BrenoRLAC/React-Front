import React from "react";
import "./Group24.css";

function Group24(props) {
  const { className } = props;

  return (
    <div className={`group-24 ${className || ""}`}>
      <div className="overlap-group1-4">
        <div className="rectangle-163"></div>
        <div className="ellipse-55"></div>
        <div className="rectangle-164"></div>
        <img className="polygon-8" src="/img/polygon-8@2x.svg" alt="Polygon 8" />
      </div>
    </div>
  );
}

export default Group24;
