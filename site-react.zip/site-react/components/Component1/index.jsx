import React from "react";
import { Link } from "react-router-dom";
import "./Component1.css";

function Component1(props) {
  const { children } = props;

  return (
    <Link to="/frame-2">
      <div className="component-1">
        <div className="entrar-1 balooda2-normal-white-24px">{children}</div>
      </div>
    </Link>
  );
}

export default Component1;
