import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import Group24 from "../Group24";
import Group123 from "../Group123";
import Group87 from "../Group87";
import Group84 from "../Group84";
import Group85 from "../Group85";
import "./Frame20.css";

function Frame20(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    sair,
    rectangle190,
    skybank,
    depositar,
    conta,
    price1,
    group21,
    atividade,
    transferir1,
    nomeDoUsuario,
    place,
    address,
    nmero,
    iconCopy,
    copiar,
    vector18,
    text10,
    validade,
    number,
    cvc,
    suaAtividade,
    vocFezUmaTransferncia,
    vocRecebeuUmaTransferncia,
    r20000,
    r15000,
    hoje,
    ontem,
    transferir2,
    spanText1,
    spanText2,
    price2,
    qualOValorDa,
    transferncia,
    transferir3,
    nomeCpfCnpj,
    group24Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-20 screen">
        <div className="overlap-group12-4">
          <div className="overlap-group15-2">
            <Group53 />
            <div className="ol-nome-do-usuario-5 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-18">
            <div className="overlap-group14-2">
              <div className="flex-row-17">
                <div className="rectangle-186-1"></div>
                <div className="overlap-group-23">
                  <div className="rectangle-46-5"></div>
                  <img className="line-9-5" src="/img/line-9-5@2x.svg" alt="Line 9" />
                  <div className="rectangle-47-5"></div>
                  <div className="rectangle-48-5"></div>
                  <img className="line-10-5" src="/img/line-10-5@2x.svg" alt="Line 10" />
                  <img className="line-11-5" src="/img/line-11-5@2x.svg" alt="Line 11" />
                </div>
                <div className="pgina-inicial-5 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-145">
                  <img className="config_icone-5" src="/img/config-icone-5@2x.svg" alt="Config_icone" />
                  <div className="configuraes-5 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-38-1" src="/img/line-37@2x.svg" alt="Line 38" />
              <img className="line-37-1" src="/img/line-37@2x.svg" alt="Line 37" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-51">
                  <div className="overlap-group-24">
                    <div className="rectangle-180-5"></div>
                    <img className="line-32-5" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31-5" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19-6" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair-5 balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-39-1" src="/img/line-37@2x.svg" alt="Line 39" />
              <div className="flex-row-18">
                <img className="rectangle-190-1" src={rectangle190} alt="Rectangle 190" />
                <div className="sky-bank-6 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group13-4">
              <div className="overlap-group-container-19">
                <div className="overlap-group17-1">
                  <div className="overlap-group2-10">
                    <Group24 className={group24Props.className} />
                    <div className="flex-col-7">
                      <div className="group-23-4">
                        <div className="overlap-group-21">
                          <div className="rectangle-161-4"></div>
                          <div className="ellipse-54-5"></div>
                          <div className="rectangle-162-5"></div>
                          <img className="polygon-7-6" src="/img/polygon-7-1@2x.svg" alt="Polygon 7" />
                        </div>
                      </div>
                      <div className="depositar-10 balooda-regular-normal-cape-cod-20px">{depositar}</div>
                    </div>
                  </div>
                  <div className="group-container-7">
                    <div className="overlap-group-25">
                      <div className="conta-4 balooda2-normal-cape-cod-36px">{conta}</div>
                      <div className="price-5 balooda-regular-normal-cape-cod-56px">{price1}</div>
                    </div>
                    <Link to="/frame-22" className="align-self-flex-center">
                      <img className="group-21-1" src={group21} alt="Group 21" />
                    </Link>
                  </div>
                  <img className="line-40" src="/img/line-61@1x.svg" alt="Line 40" />
                  <div className="atividade-4 balooda-regular-normal-cape-cod-20px">{atividade}</div>
                  <div className="transferir-8 balooda-regular-normal-picton-blue-20px-2">{transferir1}</div>
                  <Link to="/frame-24">
                    <div className="group-130">
                      <div className="overlap-group-21">
                        <div className="rectangle-161-4"></div>
                        <div className="ellipse-54-5"></div>
                        <div className="rectangle-162-5"></div>
                        <img className="polygon-7-6" src="/img/polygon-7-1@2x.svg" alt="Polygon 7" />
                      </div>
                    </div>
                  </Link>
                  <Group123 />
                  <Link to="/frame-15">
                    <div className="group-132">
                      <Group87 />
                    </div>
                  </Link>
                </div>
                <div className="overlap-group18-1">
                  <div className="overlap-group3-8">
                    <div className="overlap-group2-11">
                      <div className="nome-do-usuario-5 balooda2-bold-white-24px">{nomeDoUsuario}</div>
                      <div className="place-3 balooda2-normal-white-16px">{place}</div>
                    </div>
                    <div className="flex-row-19">
                      <div className="overlap-group4-7">
                        <div className="address-2 balooda2-bold-white-24px">{address}</div>
                        <div className="nmero-3 balooda2-normal-white-16px">{nmero}</div>
                      </div>
                      <img className="icon-copy" src={iconCopy} alt="icon-copy" />
                      <div className="copiar-2 balooda2-bold-white-16px">{copiar}</div>
                      <Link to="/frame-19">
                        <img className="vector-18-4" src={vector18} alt="Vector 18" />
                      </Link>
                    </div>
                    <div className="overlap-group-container-20">
                      <div className="overlap-group-22">
                        <div className="text-10 balooda2-bold-white-20px">{text10}</div>
                        <div className="validade-2 balooda2-normal-white-16px">{validade}</div>
                      </div>
                      <div className="overlap-group-22">
                        <div className="number-2 balooda2-bold-white-20px">{number}</div>
                        <div className="cvc-2 balooda2-normal-white-16px">{cvc}</div>
                      </div>
                    </div>
                    <div className="rectangle-176-2"></div>
                  </div>
                </div>
              </div>
              <div className="overlap-group16-1">
                <img className="line-49-2" src="/img/line-49@1x.svg" alt="Line 49" />
                <img className="line-50" src="/img/line-49@1x.svg" alt="Line 50" />
                <img className="line-51-1" src="/img/line-49@1x.svg" alt="Line 51" />
                <div className="sua-atividade balooda2-normal-cape-cod-24px">{suaAtividade}</div>
                <div className="voc-fez-uma-transferncia-2 balooda2-normal-cape-cod-28px">{vocFezUmaTransferncia}</div>
                <div className="voc-recebeu-uma-transferncia balooda2-normal-cape-cod-28px">
                  {vocRecebeuUmaTransferncia}
                </div>
                <div className="r-20000 balooda2-normal-flush-mahogany-24px">{r20000}</div>
                <div className="r-15000 balooda2-normal-fern-24px">{r15000}</div>
                <div className="hoje balooda2-normal-nobel-24px">{hoje}</div>
                <div className="ontem balooda2-normal-nobel-24px">{ontem}</div>
                <Group84 />
                <Group85 />
                <div className="rectangle-202-1"></div>
                <div className="transferir-9 balooda2-normal-cape-cod-24px">{transferir2}</div>
                <p className="saldo-disponvel-em-conta-r-250000 balooda2-normal-cape-cod-24px">
                  <span className="balooda2-normal-cape-cod-24px">{spanText1}</span>
                  <span className="balooda2-bold-cape-cod-24px">{spanText2}</span>
                </p>
                <div className="price-6 balooda-regular-normal-cape-cod-56px">{price2}</div>
                <div className="overlap-group10-5 balooda-regular-normal-cape-cod-56px">
                  <p className="qual-o-valor-da-2">{qualOValorDa}</p>
                  <div className="transferncia-2">{transferncia}</div>
                </div>
                <div className="overlap-group11-4">
                  <div className="transferir-10 balooda2-normal-white-24px">{transferir3}</div>
                </div>
                <img className="line-66-1" src="/img/line-66@2x.svg" alt="Line 66" />
                <img className="line-67-1" src="/img/line-66@2x.svg" alt="Line 67" />
                <div className="nome-cpfcnpj-2 balooda2-normal-pink-swan-36px">{nomeCpfCnpj}</div>
                <img className="line-68" src="/img/line-49@1x.svg" alt="Line 68" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame20;
