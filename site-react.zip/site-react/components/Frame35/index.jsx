import React from "react";
import "./Frame35.css";

function Frame35(props) {
  const { endereo, ruaAvenida, salvar } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-35 screen">
        <div className="flex-row-33">
          <div className="overlap-group1-23">
            <img className="line-73-2" src="/img/line-73@2x.svg" alt="Line 73" />
          </div>
          <div className="flex-col-11">
            <div className="endereo-3 balooda-regular-normal-cape-cod-48px">{endereo}</div>
            <div className="rua-avenida balooda2-semi-bold-cape-cod-20px">{ruaAvenida}</div>
          </div>
        </div>
        <img className="line-52-11" src="/img/line-52-10@1x.svg" alt="Line 52" />
        <div className="flex-row-34">
          <img className="line-69-3" src="/img/line-69-3@1x.svg" alt="Line 69" />
          <div className="overlap-group-39">
            <div className="salvar-1 balooda2-normal-white-24px">{salvar}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame35;
