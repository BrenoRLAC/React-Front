import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import Group24 from "../Group24";
import Group123 from "../Group123";
import Group87 from "../Group87";
import "./Frame22.css";

function Frame22(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    sair,
    rectangle199,
    skybank,
    conta,
    text8,
    depositar,
    group57,
    atividade,
    transferir1,
    nomeDoUsuario,
    place,
    address,
    nmero,
    copiar,
    text9,
    validade,
    number,
    cvc,
    transferir2,
    qualOValorDa,
    transferncia,
    spanText1,
    spanText2,
    price,
    nomeCpfCnpj,
    transferir3,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-22 screen">
        <div className="overlap-group11-3">
          <div className="overlap-group14-1">
            <Group53 />
            <div className="ol-nome-do-usuario-4 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-15">
            <div className="overlap-group13-3">
              <div className="flex-row-12">
                <div className="rectangle-195"></div>
                <div className="overlap-group-19">
                  <div className="rectangle-46-4"></div>
                  <img className="line-9-4" src="/img/line-9-1@2x.svg" alt="Line 9" />
                  <div className="rectangle-47-4"></div>
                  <div className="rectangle-48-4"></div>
                  <img className="line-10-4" src="/img/line-10-4@2x.svg" alt="Line 10" />
                  <img className="line-11-4" src="/img/line-11-4@2x.svg" alt="Line 11" />
                </div>
                <div className="pgina-inicial-4 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-146">
                  <img className="config_icone-4" src="/img/config-icone-4@2x.svg" alt="Config_icone" />
                  <div className="configuraes-4 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-42" src="/img/line-37@2x.svg" alt="Line 42" />
              <img className="line-41" src="/img/line-37@2x.svg" alt="Line 41" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-53-4">
                  <div className="overlap-group-20">
                    <div className="rectangle-180-4"></div>
                    <img className="line-32-4" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31-4" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19-5" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair-4 balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-43" src="/img/line-37@2x.svg" alt="Line 43" />
              <div className="flex-row-13">
                <img className="rectangle-199" src={rectangle199} alt="Rectangle 199" />
                <div className="sky-bank-5 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group12-3">
              <div className="overlap-group-container-16">
                <div className="overlap-group17">
                  <div className="overlap-group2-8">
                    <div className="flex-row-14">
                      <div className="group-container-6">
                        <div className="overlap-group3-7">
                          <div className="conta-3 balooda2-normal-cape-cod-36px">{conta}</div>
                          <div className="text-8 balooda-regular-normal-cape-cod-56px">{text8}</div>
                        </div>
                        <Group24 />
                      </div>
                      <div className="group-23-3">
                        <div className="overlap-group-17">
                          <div className="rectangle-161-2"></div>
                          <div className="ellipse-54-3"></div>
                          <div className="rectangle-162-3"></div>
                          <img className="polygon-7-5" src="/img/polygon-7-1@2x.svg" alt="Polygon 7" />
                        </div>
                      </div>
                    </div>
                    <div className="depositar-9 balooda-regular-normal-cape-cod-20px">{depositar}</div>
                  </div>
                  <img className="line-44" src="/img/line-61@1x.svg" alt="Line 44" />
                  <Link to="/frame-20">
                    <img className="group-57-1" src={group57} alt="Group 57" />
                  </Link>
                  <div className="atividade-3 balooda-regular-normal-cape-cod-20px">{atividade}</div>
                  <div className="transferir-5 balooda-regular-normal-picton-blue-20px-2">{transferir1}</div>
                  <Link to="/frame-25">
                    <div className="group-126-1">
                      <div className="overlap-group-17">
                        <div className="rectangle-161-2"></div>
                        <div className="ellipse-54-3"></div>
                        <div className="rectangle-162-3"></div>
                        <img className="polygon-7-5" src="/img/polygon-7-1@2x.svg" alt="Polygon 7" />
                      </div>
                    </div>
                  </Link>
                  <Group123 />
                  <Link to="/frame-17">
                    <div className="group-128">
                      <Group87 />
                    </div>
                  </Link>
                </div>
                <div className="overlap-group15-1">
                  <div className="overlap-group4-6">
                    <div className="overlap-group2-9">
                      <div className="nome-do-usuario-4 balooda2-bold-white-24px">{nomeDoUsuario}</div>
                      <div className="place-2 balooda2-normal-white-16px">{place}</div>
                    </div>
                    <div className="flex-row-15">
                      <div className="overlap-group5-5">
                        <div className="address-1 balooda2-bold-white-24px">{address}</div>
                        <div className="nmero-2 balooda2-normal-white-16px">{nmero}</div>
                      </div>
                      <div className="overlap-group6-3">
                        <div className="rectangle-175-2"></div>
                        <div className="line-container-1">
                          <img className="line-20-3" src="/img/line-20-2@2x.svg" alt="Line 20" />
                          <img className="line-21-1" src="/img/line-21@2x.svg" alt="Line 21" />
                        </div>
                      </div>
                      <div className="copiar-1 balooda2-bold-white-16px">{copiar}</div>
                      <Link to="/frame-21">
                        <img className="vector-18-3" src="/img/vector-18-2@2x.svg" alt="Vector 18" />
                      </Link>
                    </div>
                    <div className="overlap-group-container-17">
                      <div className="overlap-group-18">
                        <div className="text-9 balooda2-bold-white-20px">{text9}</div>
                        <div className="validade-1 balooda2-normal-white-16px">{validade}</div>
                      </div>
                      <div className="overlap-group-18">
                        <div className="number-1 balooda2-bold-white-20px">{number}</div>
                        <div className="cvc-1 balooda2-normal-white-16px">{cvc}</div>
                      </div>
                    </div>
                    <div className="rectangle-176-1"></div>
                  </div>
                </div>
              </div>
              <div className="overlap-group16 balooda2-normal-cape-cod-24px">
                <div className="overlap-group18">
                  <div className="transferir-6">{transferir2}</div>
                  <img className="line-71" src="/img/line-71@1x.svg" alt="Line 71" />
                </div>
                <div className="flex-row-16">
                  <div className="flex-col-5">
                    <div className="overlap-group9-5 balooda-regular-normal-cape-cod-56px">
                      <p className="qual-o-valor-da-1">{qualOValorDa}</p>
                      <div className="transferncia-1">{transferncia}</div>
                    </div>
                    <p className="saldo-disponvel-em-conta-1">
                      <span className="balooda2-normal-cape-cod-24px">{spanText1}</span>
                      <span className="balooda2-bold-cape-cod-24px">{spanText2}</span>
                    </p>
                    <div className="overlap-group19">
                      <div className="price-4 balooda-regular-normal-cape-cod-56px">{price}</div>
                      <img className="line-69" src="/img/line-69@2x.svg" alt="Line 69" />
                    </div>
                  </div>
                  <div className="flex-col-6">
                    <div className="nome-cpfcnpj-1 balooda2-normal-pink-swan-36px">{nomeCpfCnpj}</div>
                    <img className="line-70" src="/img/line-70@2x.svg" alt="Line 70" />
                    <div className="overlap-group10-4">
                      <div className="transferir-7 balooda2-normal-white-24px">{transferir3}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame22;
