import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import Group24 from "../Group24";
import Group87 from "../Group87";
import "./Frame26.css";

function Frame26(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    sair,
    rectangle210,
    skybank,
    conta,
    text5,
    depositar1,
    atividade,
    transferir,
    group122,
    cartoDeCrdito,
    faturaAtual,
    text4,
    nomeDoUsuario,
    limiteDisponvelDe,
    rectangle70,
    text6,
    vocFezUmaTransferncia,
    depositar2,
    qualValorVocQuer,
    depositar3,
    price,
    depositar4,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-26 screen">
        <div className="overlap-group7-3">
          <div className="overlap-group10-2">
            <Group53 />
            <div className="ol-nome-do-usuario-2 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-8">
            <div className="overlap-group9-3">
              <div className="flex-row-5">
                <div className="rectangle-206-1"></div>
                <div className="overlap-group-8">
                  <div className="rectangle-46-2"></div>
                  <img className="line-9-2" src="/img/line-9-2@2x.svg" alt="Line 9" />
                  <div className="rectangle-47-2"></div>
                  <div className="rectangle-48-2"></div>
                  <img className="line-10-2" src="/img/line-10-2@2x.svg" alt="Line 10" />
                  <img className="line-11-2" src="/img/line-11-2@2x.svg" alt="Line 11" />
                </div>
                <div className="pgina-inicial-2 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-148">
                  <img className="config_icone-2" src="/img/config-icone-2@2x.svg" alt="Config_icone" />
                  <div className="configuraes-2 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-59-1" src="/img/line-37@2x.svg" alt="Line 59" />
              <img className="line-58-1" src="/img/line-37@2x.svg" alt="Line 58" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-101-1">
                  <div className="overlap-group-9">
                    <div className="rectangle-180-2"></div>
                    <img className="line-32-2" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31-2" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19-3" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair-2 balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-60-1" src="/img/line-37@2x.svg" alt="Line 60" />
              <div className="flex-row-6">
                <img className="rectangle-210-1" src={rectangle210} alt="Rectangle 210" />
                <div className="sky-bank-2 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group8-4">
              <div className="overlap-group-container-9">
                <div className="overlap-group11-1">
                  <div className="overlap-group2-3">
                    <div className="flex-row-7">
                      <div className="group-container-4">
                        <div className="overlap-group3-3">
                          <div className="conta-1 balooda2-normal-cape-cod-36px">{conta}</div>
                          <div className="text-5 balooda-regular-normal-cape-cod-56px">{text5}</div>
                        </div>
                        <Group24 />
                      </div>
                      <div className="group-23-1">
                        <div className="overlap-group-10">
                          <div className="rectangle-16"></div>
                          <div className="ellipse-54-1"></div>
                          <div className="rectangle-162-1"></div>
                          <img className="polygon-7-1" src="/img/polygon-7-1@2x.svg" alt="Polygon 7" />
                        </div>
                      </div>
                    </div>
                    <div className="depositar-1">{depositar1}</div>
                  </div>
                  <img className="line-61-1" src="/img/line-61@1x.svg" alt="Line 61" />
                  <Link to="/frame-23">
                    <div className="group-102-1">
                      <div className="overlap-group4-4">
                        <img className="ellipse-13-1" src="/img/ellipse-13-1@2x.svg" alt="Ellipse 13" />
                        <img className="line-5-1" src="/img/line-5@2x.svg" alt="Line 5" />
                        <img className="line-7-1" src="/img/line-7@2x.svg" alt="Line 7" />
                        <img className="line-8-1" src="/img/line-8@2x.svg" alt="Line 8" />
                        <img className="line-6-1" src="/img/line-6@2x.svg" alt="Line 6" />
                      </div>
                    </div>
                  </Link>
                  <div className="atividade-1 balooda-regular-normal-cape-cod-20px">{atividade}</div>
                  <div className="transferir-3 balooda-regular-normal-cape-cod-20px">{transferir}</div>
                  <img className="group-122-1" src={group122} alt="Group 122" />
                  <Link to="/frame-21">
                    <div className="group-123-1">
                      <div className="overlap-group5-3">
                        <div className="rectangle-16"></div>
                        <div className="ellipse-55-11"></div>
                        <div className="rectangle-164-11"></div>
                        <img className="polygon-8-11" src="/img/polygon-8@2x.svg" alt="Polygon 8" />
                      </div>
                    </div>
                  </Link>
                  <Link to="/frame-16">
                    <div className="group-124-1">
                      <Group87 />
                    </div>
                  </Link>
                </div>
                <div className="overlap-group12-1">
                  <div className="overlap-group1-12">
                    <div className="rectangle-60-1"></div>
                    <div className="carto-de-crdito-1 balooda-regular-normal-white-32px">{cartoDeCrdito}</div>
                    <Link to="/frame-28">
                      <p className="fatura-atual-1 balooda2-medium-white-16px">{faturaAtual}</p>
                    </Link>
                    <div className="text-4 balooda2-medium-white-16px">{text4}</div>
                    <div className="nome-do-usuario-2 balooda2-medium-white-16px">{nomeDoUsuario}</div>
                    <p className="limite-disponvel-de-1 balooda2-medium-white-16px">{limiteDisponvelDe}</p>
                    <Link to="/frame-25">
                      <img className="vector-17-1" src="/img/vector-17@2x.svg" alt="Vector 17" />
                    </Link>
                    <img className="rectangle-70-1" src={rectangle70} alt="Rectangle 70" />
                  </div>
                  <div className="text-6 balooda2-bold-white-36px">{text6}</div>
                </div>
              </div>
              <div className="overlap-group13-1">
                <div className="voc-fez-uma-transferncia-1 balooda2-normal-cape-cod-28px">{vocFezUmaTransferncia}</div>
                <div className="overlap-group-container-10">
                  <div className="overlap-group3-4">
                    <div className="depositar-2 balooda2-normal-cape-cod-24px">{depositar2}</div>
                    <img className="line" src="/img/line-49@1x.svg" alt="Line 52" />
                    <img className="line" src="/img/line-49@1x.svg" alt="Line 65" />
                  </div>
                  <div className="overlap-group-11 balooda-regular-normal-cape-cod-56px">
                    <div className="qual-valor-voc-quer">{qualValorVocQuer}</div>
                    <div className="depositar-3">{depositar3}</div>
                  </div>
                  <div className="overlap-group2-4">
                    <div className="price-1 balooda-regular-normal-cape-cod-56px">{price}</div>
                    <img className="line-20" src="/img/line-20@2x.svg" alt="Line 20" />
                  </div>
                  <div className="overlap-group1-13">
                    <div className="depositar-4 balooda2-normal-white-24px">{depositar4}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame26;
