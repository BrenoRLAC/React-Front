import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import "./Frame27.css";

function Frame27(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    sair,
    rectangle190,
    skybank,
    nomeDoUsuario1,
    nomeDoUsuario2,
    seusDados1,
    seusDados2,
    gerencieSeusDadosPessoais,
    group174,
    seuCarto,
    gerencieSeuCarto,
    group175,
    endereo,
    altereSeuEndereoOuAdicioneOutro,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-27 screen">
        <div className="overlap-group5-1">
          <div className="overlap-group8">
            <Group53 />
            <div className="ol-nome-do-usuario balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-1">
            <div className="overlap-group7">
              <Link to="/frame-2">
                <div className="group-152">
                  <div className="overlap-group-1">
                    <div className="rectangle-46"></div>
                    <img className="line-9" src="/img/line-9@2x.svg" alt="Line 9" />
                    <div className="rectangle-47"></div>
                    <div className="rectangle-48"></div>
                    <img className="line-10" src="/img/line-10@2x.svg" alt="Line 10" />
                    <img className="line-11" src="/img/line-11@2x.svg" alt="Line 11" />
                  </div>
                  <div className="pgina-inicial balooda-regular-normal-cape-cod-20px">{pginaInicial}</div>
                </div>
              </Link>
              <div className="flex-row">
                <div className="rectangle-186"></div>
                <img className="config_icone" src="/img/config-icone@2x.svg" alt="Config_icone" />
                <div className="configuraes balooda-regular-normal-picton-blue-20px">{configuraes}</div>
              </div>
              <img className="line-38" src="/img/line-37@2x.svg" alt="Line 38" />
              <img className="line-37" src="/img/line-37@2x.svg" alt="Line 37" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-55">
                  <div className="overlap-group-2">
                    <div className="rectangle-180"></div>
                    <img className="line-32" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-39" src="/img/line-37@2x.svg" alt="Line 39" />
              <div className="flex-row-1">
                <img className="rectangle-190" src={rectangle190} alt="Rectangle 190" />
                <div className="sky-bank balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group-container-2">
              <div className="group-container">
                <div className="group-57">
                  <div className="ellipse-63"></div>
                  <img className="ellipse-64" src="/img/ellipse-64-1@2x.svg" alt="Ellipse 64" />
                </div>
                <div className="nome-do-usuario-container balooda-regular-normal-cape-cod-36px">
                  <div className="nome-do-usuario">{nomeDoUsuario1}</div>
                  <div className="nome-do-usuario">{nomeDoUsuario2}</div>
                </div>
              </div>
              <div className="overlap-group10">
                <div className="overlap-group4-1">
                  <Link to="/frame-30">
                    <div className="group-153">
                      <div className="overlap-group1-1">
                        <div className="group-58">
                          <div className="ellipse-63-1"></div>
                          <img className="ellipse-64" src="/img/ellipse-64-2@2x.svg" alt="Ellipse 64" />
                        </div>
                        <div className="ellipse-62"></div>
                      </div>
                      <div className="seus-dados-container">
                        <div className="seus-dados balooda-regular-normal-cape-cod-34px">{seusDados1}</div>
                        <div className="seus-dados-1 balooda-regular-normal-cape-cod-34px">{seusDados2}</div>
                        <div className="gerencie-seus-dados-pessoais balooda2-normal-cape-cod-24px">
                          {gerencieSeusDadosPessoais}
                        </div>
                      </div>
                      <img className="vector-18" src="/img/vector-18@2x.svg" alt="Vector 18" />
                    </div>
                  </Link>
                  <img className="line-49" src="/img/line-49@1x.svg" alt="Line 49" />
                  <Link to="/frame-28">
                    <div className="group-154">
                      <img className="group-17" src={group174} alt="Group 174" />
                      <div className="seu-carto-container">
                        <div className="seu-carto balooda-regular-normal-cape-cod-34px">{seuCarto}</div>
                        <div className="gerencie-seu-carto balooda2-normal-cape-cod-24px">{gerencieSeuCarto}</div>
                      </div>
                      <img className="vector-19-1" src="/img/vector-18@2x.svg" alt="Vector 19" />
                    </div>
                  </Link>
                  <Link to="/frame-32">
                    <div className="group-155">
                      <img className="group-17" src={group175} alt="Group 175" />
                      <div className="endereo-container">
                        <div className="endereo balooda-regular-normal-cape-cod-34px">{endereo}</div>
                        <p className="altere-seu-endereo-ou-adicione-outro balooda2-normal-cape-cod-24px">
                          {altereSeuEndereoOuAdicioneOutro}
                        </p>
                      </div>
                      <img className="vector-20" src="/img/vector-18@2x.svg" alt="Vector 20" />
                    </div>
                  </Link>
                </div>
                <img className="line-49-1" src="/img/line-49@1x.svg" alt="Line 49" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame27;
