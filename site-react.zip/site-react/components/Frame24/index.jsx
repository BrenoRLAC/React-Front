import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import Group87 from "../Group87";
import Group23 from "../Group23";
import "./Frame24.css";

function Frame24(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    sair,
    rectangle172,
    skybank,
    conta,
    price1,
    atividade,
    transferir,
    depositar1,
    nomeDoUsuario,
    place,
    address,
    nmero,
    copiar,
    text7,
    validade,
    number,
    cvc,
    depositar2,
    qualValorVocQuer,
    depositar3,
    price2,
    depositar4,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-24 screen">
        <div className="overlap-group7-4">
          <div className="overlap-group10-3">
            <Group53 />
            <div className="ol-nome-do-usuario-3 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-11">
            <div className="overlap-group9-4">
              <div className="flex-row-8">
                <div className="rectangle-175"></div>
                <div className="overlap-group-14">
                  <div className="rectangle-46-3"></div>
                  <img className="line-9-3" src="/img/line-9-3@2x.svg" alt="Line 9" />
                  <div className="rectangle-47-3"></div>
                  <div className="rectangle-48-3"></div>
                  <img className="line-10-3" src="/img/line-10-3@2x.svg" alt="Line 10" />
                  <img className="line-11-3" src="/img/line-11-3@2x.svg" alt="Line 11" />
                </div>
                <div className="pgina-inicial-3 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-149">
                  <img className="config_icone-3" src="/img/config-icone-3@2x.svg" alt="Config_icone" />
                  <div className="configuraes-3 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-35" src="/img/line-37@2x.svg" alt="Line 35" />
              <img className="line-33" src="/img/line-37@2x.svg" alt="Line 33" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-98">
                  <div className="overlap-group-15">
                    <div className="rectangle-180-3"></div>
                    <img className="line-32-3" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31-3" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19-4" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair-3 balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-34" src="/img/line-37@2x.svg" alt="Line 34" />
              <div className="flex-row-9">
                <img className="rectangle-172" src={rectangle172} alt="Rectangle 172" />
                <div className="sky-bank-4 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group8-5">
              <div className="overlap-group-container-12">
                <div className="overlap-group11-2">
                  <div className="group-container-5">
                    <div className="overlap-group13-2">
                      <div className="conta-2 balooda2-normal-cape-cod-36px">{conta}</div>
                      <div className="price-2 balooda-regular-normal-cape-cod-56px">{price1}</div>
                    </div>
                    <Link to="/frame-25">
                      <div className="group-21">
                        <div className="ellipse-container">
                          <div className="ellipse-56"></div>
                          <img className="ellipse-58" src="/img/ellipse-58@2x.svg" alt="Ellipse 58" />
                        </div>
                      </div>
                    </Link>
                  </div>
                  <img className="line-36" src="/img/line-61@1x.svg" alt="Line 36" />
                  <div className="flex-row-10">
                    <div className="flex-col-2">
                      <Link to="/frame-15">
                        <div className="group-89">
                          <Group87 />
                        </div>
                      </Link>
                      <div className="atividade-2 balooda-regular-normal-cape-cod-20px">{atividade}</div>
                    </div>
                    <div className="flex-col-3">
                      <Link to="/frame-20">
                        <div className="group-88">
                          <div className="overlap-group2-5">
                            <div className="rectangle-163-11"></div>
                            <div className="ellipse-55-12"></div>
                            <div className="rectangle-164-12"></div>
                            <img className="polygon-8-12" src="/img/polygon-8@2x.svg" alt="Polygon 8" />
                          </div>
                        </div>
                      </Link>
                      <div className="transferir-4 balooda-regular-normal-cape-cod-20px">{transferir}</div>
                    </div>
                    <div className="flex-col-4">
                      <Group23 />
                      <div className="depositar-5 balooda-regular-normal-picton-blue-20px-4">{depositar1}</div>
                    </div>
                  </div>
                </div>
                <div className="overlap-group12-2">
                  <div className="overlap-group5-4">
                    <div className="overlap-group3-5">
                      <div className="nome-do-usuario-3 balooda2-bold-white-24px">{nomeDoUsuario}</div>
                      <div className="place-1 balooda2-normal-white-16px">{place}</div>
                    </div>
                    <div className="flex-row-11">
                      <div className="overlap-group4-5">
                        <div className="address balooda2-bold-white-24px">{address}</div>
                        <div className="nmero-1 balooda2-normal-white-16px">{nmero}</div>
                      </div>
                      <div className="overlap-group6-2">
                        <div className="rectangle-175-1"></div>
                        <div className="line-container">
                          <img className="line-20-1" src="/img/line-20-2@2x.svg" alt="Line 20" />
                          <img className="line-21" src="/img/line-21@2x.svg" alt="Line 21" />
                        </div>
                      </div>
                      <div className="copiar balooda2-bold-white-16px">{copiar}</div>
                      <Link to="/frame-23">
                        <img className="vector-18-2" src="/img/vector-18-2@2x.svg" alt="Vector 18" />
                      </Link>
                    </div>
                    <div className="overlap-group-container-13">
                      <div className="overlap-group-13">
                        <div className="text-7 balooda2-bold-white-20px">{text7}</div>
                        <div className="validade balooda2-normal-white-16px">{validade}</div>
                      </div>
                      <div className="overlap-group-13">
                        <div className="number balooda2-bold-white-20px">{number}</div>
                        <div className="cvc balooda2-normal-white-16px">{cvc}</div>
                      </div>
                    </div>
                    <div className="rectangle-176"></div>
                  </div>
                </div>
              </div>
              <div className="overlap-group-container-14">
                <div className="overlap-group3-6">
                  <div className="depositar-6 balooda2-normal-cape-cod-24px">{depositar2}</div>
                  <img className="line-1" src="/img/line-49@1x.svg" alt="Line 52" />
                  <img className="line-1" src="/img/line-49@1x.svg" alt="Line 65" />
                </div>
                <div className="overlap-group-16 balooda-regular-normal-cape-cod-56px">
                  <div className="qual-valor-voc-quer-1">{qualValorVocQuer}</div>
                  <div className="depositar-7">{depositar3}</div>
                </div>
                <div className="overlap-group2-6">
                  <div className="price-3 balooda-regular-normal-cape-cod-56px">{price2}</div>
                  <img className="line-20-2" src="/img/line-20@2x.svg" alt="Line 20" />
                </div>
                <div className="overlap-group1-14">
                  <div className="depositar-8 balooda2-normal-white-24px">{depositar4}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame24;
