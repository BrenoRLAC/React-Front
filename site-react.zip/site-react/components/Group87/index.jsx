import React from "react";
import "./Group87.css";

function Group87(props) {
  const { className } = props;

  return (
    <div className={`group-87 ${className || ""}`}>
      <img className="line-52" src="/img/line-52@2x.svg" alt="Line 52" />
      <img className="line-53" src="/img/line-53@2x.svg" alt="Line 53" />
      <img className="line-54" src="/img/line-53@2x.svg" alt="Line 54" />
    </div>
  );
}

export default Group87;
