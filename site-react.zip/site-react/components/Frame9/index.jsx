import React from "react";
import { Link } from "react-router-dom";
import "./Frame9.css";

function Frame9() {
  return (
    <div className="container-center-horizontal">
      <div className="frame-9 screen" onclick="window.open('frame-8.html', '_self');">
        <div className="rectangle-181"></div>
      </div>
    </div>
  );
}

export default Frame9;
