import React from "react";
import "./Group85.css";

function Group85(props) {
  const { className } = props;

  return (
    <div className={`group-85 ${className || ""}`}>
      <div className="overlap-group7-6">
        <div className="rectangle-163-12"></div>
        <div className="ellipse-55-13"></div>
        <div className="rectangle-164-13"></div>
        <img className="polygon-8-13" src="/img/polygon-8-8@2x.svg" alt="Polygon 8" />
      </div>
    </div>
  );
}

export default Group85;
