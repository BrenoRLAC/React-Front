import React from "react";
import { Link } from "react-router-dom";
import "./Frame8.css";

function Frame8(props) {
  const { children } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-8 screen" onclick="window.open('frame-10.html', '_self');">
        <div className="overlap-group-36">
          <p className="bem-vindo-a-ao-sky-bank barlow-normal-white-64px">{children}</p>
        </div>
      </div>
    </div>
  );
}

export default Frame8;
