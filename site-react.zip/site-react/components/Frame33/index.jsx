import React from "react";
import "./Frame33.css";

function Frame33(props) {
  const { ruaAvenida, polygon11, polygon12 } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-33 screen">
        <div className="overlap-group-67">
          <div className="rua-avenida-1">{ruaAvenida}</div>
          <div className="rectangle-219"></div>
          <img className="polygon-11" src={polygon11} alt="Polygon 11" />
          <img className="polygon-12" src={polygon12} alt="Polygon 12" />
        </div>
      </div>
    </div>
  );
}

export default Frame33;
