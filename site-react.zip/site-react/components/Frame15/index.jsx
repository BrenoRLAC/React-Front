import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import Group24 from "../Group24";
import Group85 from "../Group85";
import Group84 from "../Group84";
import "./Frame15.css";

function Frame15(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    sair,
    rectangle190,
    skybank,
    transferir,
    depositar,
    conta,
    price,
    atividade,
    group92,
    group93,
    nomeDoUsuario,
    place,
    address,
    nmero,
    copiar,
    text19,
    validade,
    number,
    cvc,
    suaAtividade,
    vocFezUmaTransferncia,
    r20000,
    hoje,
    vocRecebeuUmaTransferncia,
    r15000,
    ontem,
    group24Props,
    group85Props,
    group84Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-15 screen">
        <div className="overlap-group10-9">
          <div className="overlap-group12-9">
            <Group53 />
            <div className="ol-nome-do-usuario-10 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-33">
            <div className="overlap-group13-9">
              <div className="flex-row-48">
                <div className="rectangle-186-3"></div>
                <div className="overlap-group-50">
                  <div className="rectangle-46-9"></div>
                  <img className="line-9-9" src="/img/line-9-5@2x.svg" alt="Line 9" />
                  <div className="rectangle-47-9"></div>
                  <div className="rectangle-48-9"></div>
                  <img className="line-10-9" src="/img/line-10-9@2x.svg" alt="Line 10" />
                  <img className="line-11-9" src="/img/line-11-9@2x.svg" alt="Line 11" />
                </div>
                <div className="pgina-inicial-10 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-142">
                  <img className="config_icone-9" src="/img/config-icone-9@2x.svg" alt="Config_icone" />
                  <div className="configuraes-10 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-38-3" src="/img/line-37@2x.svg" alt="Line 38" />
              <img className="line-37-3" src="/img/line-37@2x.svg" alt="Line 37" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-51-1">
                  <div className="overlap-group-51">
                    <div className="rectangle-180-9"></div>
                    <img className="line-32-9" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31-9" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19-10" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair-9 balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-39-3" src="/img/line-37@2x.svg" alt="Line 39" />
              <div className="flex-row-49">
                <img className="rectangle-190-3" src={rectangle190} alt="Rectangle 190" />
                <div className="sky-bank-11 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group11-9">
              <div className="overlap-group-container-34">
                <div className="overlap-group14-7">
                  <div className="flex-row-50">
                    <div className="flex-col-19">
                      <Group24 className={group24Props.className} />
                      <div className="transferir-15 balooda-regular-normal-cape-cod-20px">{transferir}</div>
                    </div>
                    <div className="flex-col-20">
                      <div className="group-23-9">
                        <div className="overlap-group-48">
                          <div className="rectangle-161-11"></div>
                          <div className="ellipse-54-15"></div>
                          <div className="rectangle-162-15"></div>
                          <img className="polygon-7-16" src="/img/polygon-7@2x.svg" alt="Polygon 7" />
                        </div>
                      </div>
                      <div className="depositar-18 balooda-regular-normal-cape-cod-20px">{depositar}</div>
                    </div>
                  </div>
                  <div className="group-container-10">
                    <div className="overlap-group1-26">
                      <div className="conta-9 balooda2-normal-cape-cod-36px">{conta}</div>
                      <div className="price-10 balooda-regular-normal-cape-cod-56px">{price}</div>
                    </div>
                    <Link to="/frame-17" className="align-self-flex-center">
                      <div className="group-21-3">
                        <div className="ellipse-container-2">
                          <div className="ellipse-56-2"></div>
                          <img className="ellipse-58-2" src="/img/ellipse-58-2@2x.svg" alt="Ellipse 58" />
                        </div>
                      </div>
                    </Link>
                  </div>
                  <img className="line-40-3" src="/img/line-61@1x.svg" alt="Line 40" />
                  <div className="atividade-9 balooda-regular-normal-picton-blue-20px-3">{atividade}</div>
                  <Link to="/frame-24">
                    <div className="group-91">
                      <div className="overlap-group-48">
                        <div className="rectangle-161-11"></div>
                        <div className="ellipse-54-15"></div>
                        <div className="rectangle-162-15"></div>
                        <img className="polygon-7-16" src="/img/polygon-7-1@2x.svg" alt="Polygon 7" />
                      </div>
                    </div>
                  </Link>
                  <Link to="/frame-20">
                    <img className="group-92" src={group92} alt="Group 92" />
                  </Link>
                  <img className="group-93-2" src={group93} alt="Group 93" />
                </div>
                <div className="overlap-group15-7">
                  <div className="overlap-group3-15">
                    <div className="overlap-group2-17">
                      <div className="nome-do-usuario-10 balooda2-bold-white-24px">{nomeDoUsuario}</div>
                      <div className="place-6 balooda2-normal-white-16px">{place}</div>
                    </div>
                    <div className="flex-row-51">
                      <div className="overlap-group4-13">
                        <div className="address-5 balooda2-bold-white-24px">{address}</div>
                        <div className="nmero-7 balooda2-normal-white-16px">{nmero}</div>
                      </div>
                      <div className="overlap-group6-8">
                        <div className="rectangle-175-6"></div>
                        <div className="line-container-4">
                          <img className="line-20-7" src="/img/line-20-2@2x.svg" alt="Line 20" />
                          <img className="line-21-4" src="/img/line-21@2x.svg" alt="Line 21" />
                        </div>
                      </div>
                      <div className="copiar-5 balooda2-bold-white-16px">{copiar}</div>
                      <Link to="/frame-2">
                        <img className="vector-18-7" src="/img/vector-18-2@2x.svg" alt="Vector 18" />
                      </Link>
                    </div>
                    <div className="overlap-group-container-35">
                      <div className="overlap-group-49">
                        <div className="text-19 balooda2-bold-white-20px">{text19}</div>
                        <div className="validade-5 balooda2-normal-white-16px">{validade}</div>
                      </div>
                      <div className="overlap-group-49">
                        <div className="number-5 balooda2-bold-white-20px">{number}</div>
                        <div className="cvc-5 balooda2-normal-white-16px">{cvc}</div>
                      </div>
                    </div>
                    <div className="rectangle-176-5"></div>
                  </div>
                </div>
              </div>
              <div className="overlap-group9-10">
                <div className="flex-col-21">
                  <div className="overlap-group2-18">
                    <div className="sua-atividade-4 balooda2-normal-cape-cod-24px">{suaAtividade}</div>
                    <img className="line-43-4" src="/img/line-43-2@1x.svg" alt="Line 43" />
                  </div>
                  <div className="flex-row-52">
                    <Group85 className={group85Props.className} />
                    <div className="voc-fez-uma-transferncia-6 balooda2-normal-cape-cod-28px">
                      {vocFezUmaTransferncia}
                    </div>
                    <div className="overlap-group3-16">
                      <div className="r-20000-4 balooda2-normal-flush-mahogany-24px">{r20000}</div>
                      <div className="hoje-4 balooda2-normal-nobel-24px">{hoje}</div>
                    </div>
                  </div>
                  <img className="line-4-3" src="/img/line-49@1x.svg" alt="Line 44" />
                </div>
                <div className="flex-row-53">
                  <Group84 className={group84Props.className} />
                  <div className="voc-recebeu-uma-transferncia-4 balooda2-normal-cape-cod-28px">
                    {vocRecebeuUmaTransferncia}
                  </div>
                  <div className="overlap-group4-14">
                    <div className="r-15000-4 balooda2-normal-fern-24px">{r15000}</div>
                    <div className="ontem-4 balooda2-normal-nobel-24px">{ontem}</div>
                  </div>
                </div>
                <img className="line-4-3" src="/img/line-49@1x.svg" alt="Line 45" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame15;
