import React from "react";
import "./Group23.css";

function Group23(props) {
  const { className } = props;

  return (
    <div className={`group-23-2 ${className || ""}`}>
      <div className="overlap-group1-15">
        <div className="rectangle-161-1"></div>
        <div className="ellipse-54-2"></div>
        <div className="rectangle-162-2"></div>
        <img className="polygon-7-2" src="/img/polygon-7-3@2x.svg" alt="Polygon 7" />
      </div>
    </div>
  );
}

export default Group23;
