import React from "react";
import "./Group123.css";

function Group123() {
  return (
    <div className="group-123">
      <div className="overlap-group6-1">
        <div className="rectangle-163-8"></div>
        <div className="ellipse-55-8"></div>
        <div className="rectangle-164-8"></div>
        <img className="polygon-8-8" src="/img/polygon-8-1@2x.svg" alt="Polygon 8" />
      </div>
    </div>
  );
}

export default Group123;
