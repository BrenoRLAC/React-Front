import React from "react";
import Group169 from "../Group169";
import "./Frame36.css";

function Frame36(props) {
  const { nmero } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-36 screen">
        <div className="flex-row-40">
          <div className="overlap-group-42">
            <img className="line-73-3" src="/img/line-73@2x.svg" alt="Line 73" />
          </div>
          <div className="nmero-6 balooda-regular-normal-cape-cod-48px">{nmero}</div>
        </div>
        <img className="line-52-12" src="/img/line-52-10@1x.svg" alt="Line 52" />
        <Group169 />
        <img className="line-69-4" src="/img/line-69-4@2x.svg" alt="Line 69" />
      </div>
    </div>
  );
}

export default Frame36;
