import React from "react";
import "./Group139.css";

function Group139(props) {
  const { className } = props;

  return (
    <div className={`group-139 ${className || ""}`}>
      <img className="line-50-1" src="/img/line-50-1@1x.svg" alt="Line 50" />
    </div>
  );
}

export default Group139;
