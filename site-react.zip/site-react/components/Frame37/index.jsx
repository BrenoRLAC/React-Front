import React from "react";
import Group169 from "../Group169";
import "./Frame37.css";

function Frame37(props) {
  const { complemento, group169Props } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-37 screen">
        <div className="flex-row-41">
          <div className="overlap-group-43">
            <img className="line-73-4" src="/img/line-73@2x.svg" alt="Line 73" />
          </div>
          <div className="complemento-1 balooda-regular-normal-cape-cod-48px">{complemento}</div>
        </div>
        <img className="line-52-13" src="/img/line-52-10@1x.svg" alt="Line 52" />
        <Group169 className={group169Props.className} />
        <img className="line-69-5" src="/img/line-69-5@2x.svg" alt="Line 69" />
      </div>
    </div>
  );
}

export default Frame37;
