import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import Group97 from "../Group97";
import Group85 from "../Group85";
import Group84 from "../Group84";
import "./Frame2.css";

function Frame2(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    sair,
    rectangle172,
    skybank,
    conta,
    price,
    atividade,
    transferir,
    depositar,
    cartoDeCrdito,
    faturaAtual,
    text15,
    nomeDoUsuario,
    limiteDisponvelDeR178010,
    rectangle70,
    suaAtividade,
    vocFezUmaTransferncia,
    r20000,
    hoje,
    vocRecebeuUmaTransferncia,
    r15000,
    ontem,
    group97Props,
    group85Props,
    group84Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-2 screen">
        <div className="overlap-group7-9">
          <div className="overlap-group9-8">
            <Group53 />
            <div className="ol-nome-do-usuario-8 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-29">
            <div className="overlap-group10-7">
              <div className="flex-row-35">
                <div className="rectangle-175-5"></div>
                <div className="overlap-group-40">
                  <div className="rectangle-46-8"></div>
                  <img className="line-9-8" src="/img/line-9-5@2x.svg" alt="Line 9" />
                  <div className="rectangle-47-8"></div>
                  <div className="rectangle-48-8"></div>
                  <img className="line-10-8" src="/img/line-10-8@2x.svg" alt="Line 10" />
                  <img className="line-11-8" src="/img/line-11-8@2x.svg" alt="Line 11" />
                </div>
                <div className="pgina-inicial-8 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-141">
                  <img className="config_icone-8" src="/img/config-icone-8@2x.svg" alt="Config_icone" />
                  <div className="configuraes-8 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-35-1" src="/img/line-37@2x.svg" alt="Line 35" />
              <img className="line-33-1" src="/img/line-37@2x.svg" alt="Line 33" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-52">
                  <div className="overlap-group-41">
                    <div className="rectangle-180-7"></div>
                    <img className="line-32-7" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31-7" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19-8" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair-7 balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-34-1" src="/img/line-37@2x.svg" alt="Line 34" />
              <div className="flex-row-36">
                <img className="rectangle-172-1" src={rectangle172} alt="Rectangle 172" />
                <div className="sky-bank-9 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group8-8">
              <div className="overlap-group-container-30">
                <div className="overlap-group12-7">
                  <div className="overlap-group17-2">
                    <div className="group-container-9">
                      <div className="overlap-group1-24">
                        <div className="conta-7 balooda2-normal-cape-cod-36px">{conta}</div>
                        <div className="price-9 balooda-regular-normal-cape-cod-56px">{price}</div>
                      </div>
                      <Link to="/frame-16" className="align-self-flex-center">
                        <div className="group-21-2">
                          <div className="ellipse-container-1">
                            <div className="ellipse-56-1"></div>
                            <img className="ellipse-58-1" src="/img/ellipse-58-1@2x.svg" alt="Ellipse 58" />
                          </div>
                        </div>
                      </Link>
                    </div>
                    <img className="line-36-1" src="/img/line-61@1x.svg" alt="Line 36" />
                  </div>
                  <div className="flex-row-37">
                    <div className="flex-col-12">
                      <Group97 className={group97Props.className} group87Props={group97Props.group87Props} />
                      <div className="atividade-7 balooda-regular-normal-picton-blue-20px-3">{atividade}</div>
                    </div>
                    <div className="flex-col-13">
                      <Link to="/frame-19">
                        <div className="group-88-1">
                          <div className="overlap-group3-13">
                            <div className="rectangle-16-2"></div>
                            <div className="ellipse-55-20"></div>
                            <div className="rectangle-164-20"></div>
                            <img className="polygon-8-20" src="/img/polygon-8@2x.svg" alt="Polygon 8" />
                          </div>
                        </div>
                      </Link>
                      <div className="transferir-13 balooda-regular-normal-cape-cod-20px">{transferir}</div>
                    </div>
                    <div className="flex-col-14">
                      <Link to="/frame-23">
                        <div className="group-23-7">
                          <div className="overlap-group2-16">
                            <div className="rectangle-16-2"></div>
                            <div className="ellipse-54-13"></div>
                            <div className="rectangle-162-13"></div>
                            <img className="polygon-7-14" src="/img/polygon-7-1@2x.svg" alt="Polygon 7" />
                          </div>
                        </div>
                      </Link>
                      <div className="depositar-16 balooda-regular-normal-cape-cod-20px">{depositar}</div>
                    </div>
                  </div>
                </div>
                <div className="overlap-group11-7">
                  <div className="rectangle-60-2"></div>
                  <div className="carto-de-crdito-2 balooda-regular-normal-white-32px">{cartoDeCrdito}</div>
                  <Link to="/frame-28">
                    <p className="fatura-atual-2 balooda2-medium-white-16px">{faturaAtual}</p>
                  </Link>
                  <div className="text-15 balooda2-medium-white-16px">{text15}</div>
                  <div className="nome-do-usuario-8 balooda2-medium-white-16px">{nomeDoUsuario}</div>
                  <div className="limite-disponvel-de-r178010 balooda2-medium-white-16px">
                    {limiteDisponvelDeR178010}
                  </div>
                  <img className="x" src="/img/----@2x.svg" alt="****" />
                  <Link to="/frame-15">
                    <img className="vector-17-2" src="/img/vector-17@2x.svg" alt="Vector 17" />
                  </Link>
                  <img className="rectangle-70-2" src={rectangle70} alt="Rectangle 70" />
                </div>
              </div>
              <div className="overlap-group13-7">
                <div className="flex-col-15">
                  <div className="overlap-group15-5">
                    <div className="sua-atividade-2 balooda2-normal-cape-cod-24px">{suaAtividade}</div>
                    <img className="line-40-1" src="/img/line-49@1x.svg" alt="Line 40" />
                  </div>
                  <div className="flex-row-38">
                    <Group85 className={group85Props.className} />
                    <div className="voc-fez-uma-transferncia-4 balooda2-normal-cape-cod-28px">
                      {vocFezUmaTransferncia}
                    </div>
                    <div className="overlap-group14-5">
                      <div className="r-20000-2 balooda2-normal-flush-mahogany-24px">{r20000}</div>
                      <div className="hoje-2 balooda2-normal-nobel-24px">{hoje}</div>
                    </div>
                  </div>
                  <img className="line-4-1" src="/img/line-49@1x.svg" alt="Line 41" />
                </div>
                <div className="flex-row-39">
                  <Group84 className={group84Props.className} />
                  <div className="voc-recebeu-uma-transferncia-2 balooda2-normal-cape-cod-28px">
                    {vocRecebeuUmaTransferncia}
                  </div>
                  <div className="overlap-group16-4">
                    <div className="r-15000-2 balooda2-normal-fern-24px">{r15000}</div>
                    <div className="ontem-2 balooda2-normal-nobel-24px">{ontem}</div>
                  </div>
                </div>
                <img className="line-4-1" src="/img/line-49@1x.svg" alt="Line 42" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame2;
