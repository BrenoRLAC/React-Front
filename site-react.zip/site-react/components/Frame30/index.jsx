import React from "react";
import { Link } from "react-router-dom";
import Group139 from "../Group139";
import Group160 from "../Group160";
import Group53 from "../Group53";
import "./Frame30.css";

function Frame30(props) {
  const {
    configuraes,
    iconSettings,
    iconHome,
    pginaInicial,
    sair,
    rectangle190,
    skybank,
    nomeCompleto,
    nomeDoUsuario,
    nomeEmailCom,
    phone,
    text24,
    nmero,
    cpf,
    senha,
    group59,
    seusDados,
    gerencieSeusDadosPessoais,
    voltar,
    olNomeDoUsuario,
    group139Props,
    group160Props,
    group53Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-30 screen">
        <div className="overlap-group3-21">
          <div className="rectangle-183-2"></div>
          <div className="rectangle-184-2"></div>
          <div className="rectangle-185-2"></div>
          <div className="configuraes-15 balooda-regular-normal-picton-blue-20px">{configuraes}</div>
          <img className="icon-settings-1" src={iconSettings} alt="icon-settings" />
          <div className="rectangle-186-6"></div>
          <Link to="/frame-2">
            <div className="group-152-3">
              <img className="icon-home-1" src={iconHome} alt="icon-home" />
              <div className="pgina-inicial-15 balooda-regular-normal-cape-cod-20px">{pginaInicial}</div>
            </div>
          </Link>
          <a href="javascript:ShowOverlay('frame-5', 'animate-appear');">
            <div className="group-55-5">
              <div className="overlap-group-66">
                <div className="rectangle-180-14"></div>
                <img className="line-32-14" src="/img/line-32@2x.svg" alt="Line 32" />
                <img className="line-31-14" src="/img/line-31@2x.svg" alt="Line 31" />
                <img className="vector-19-15" src="/img/vector-19@2x.svg" alt="Vector 19" />
              </div>
              <div className="sair-14 balooda-regular-normal-cape-cod-20px">{sair}</div>
            </div>
          </a>
          <img className="line-37-6" src="/img/line-37@2x.svg" alt="Line 37" />
          <img className="line-38-6" src="/img/line-37@2x.svg" alt="Line 38" />
          <img className="line-39-6" src="/img/line-37@2x.svg" alt="Line 39" />
          <img className="rectangle-190-6" src={rectangle190} alt="Rectangle 190" />
          <div className="sky-bank-16 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
          <div className="overlap-group1-32">
            <Group139 className={group139Props.className} />
            <div className="nome-completo-1 balooda2-semi-bold-cape-cod-32px">{nomeCompleto}</div>
            <div className="nome-do-usuario-14 balooda2-normal-silver-chalice-32px">{nomeDoUsuario}</div>
            <div className="nomeemailcom balooda2-normal-silver-chalice-32px">{nomeEmailCom}</div>
            <div className="phone balooda2-normal-silver-chalice-32px">{phone}</div>
            <div className="text-24 balooda2-semi-bold-silver-chalice-32px">{text24}</div>
            <div className="nmero-10 balooda2-semi-bold-cape-cod-32px">{nmero}</div>
            <div className="cpf-2 balooda2-semi-bold-cape-cod-32px">{cpf}</div>
            <div className="senha-2 balooda2-semi-bold-cape-cod-32px">{senha}</div>
          </div>
          <div className="group-161-1">
            <img className="group-157" src="/img/group-157-1@2x.svg" alt="Group 157" />
          </div>
          <Group160 />
          <Group160 className={group160Props.className} />
          <div className="overlap-group2-23">
            <img className="group-59" src={group59} alt="Group 59" />
            <div className="seus-dados-container-1">
              <div className="seus-dados-2 balooda-regular-normal-cape-cod-34px">{seusDados}</div>
              <div className="gerencie-seus-dados-pessoais-1 balooda2-normal-cape-cod-24px">
                {gerencieSeusDadosPessoais}
              </div>
            </div>
            <Link to="/frame-27">
              <div className="voltar-4 balooda2-normal-dodger-blue-24px">{voltar}</div>
            </Link>
          </div>
          <div className="rectangle-187-2"></div>
          <div className="ol-nome-do-usuario-15 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          <Group53 className={group53Props.className} />
        </div>
      </div>
    </div>
  );
}

export default Frame30;
