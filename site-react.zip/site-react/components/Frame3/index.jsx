import React from "react";
import { Link } from "react-router-dom";
import "./Frame3.css";

function Frame3(props) {
  const { cadastrar, nomeCompleto, senha, spanText1, spanText2, eMail, cpf, avanar, voltar } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-3 screen">
        <div className="overlap-group1-31">
          <div className="rectangle-79"></div>
          <div className="cadastrar balooda-regular-normal-cape-cod-36px">{cadastrar}</div>
          <div className="nome-completo balooda2-normal-silver-chalice-20px">{nomeCompleto}</div>
          <div className="senha-1 balooda2-normal-silver-chalice-20px">{senha}</div>
          <img className="line-20-10" src="/img/line-20-10@2x.svg" alt="Line 20" />
          <div className="data-de-nascimento-ddmmaaaa">
            <span className="balooda2-normal-silver-chalice-20px">{spanText1}</span>
            <span className="span1">{spanText2}</span>
          </div>
          <img className="line-24" src="/img/line-24@2x.svg" alt="Line 24" />
          <div className="e-mail balooda2-normal-silver-chalice-20px">{eMail}</div>
          <img className="line-22" src="/img/line-22@2x.svg" alt="Line 22" />
          <div className="cpf-1 balooda2-normal-silver-chalice-20px">{cpf}</div>
          <img className="line-23" src="/img/line-23@2x.svg" alt="Line 23" />
          <img className="line-21-5" src="/img/line-21-5@2x.svg" alt="Line 21" />
          <Link to="/frame-4">
            <img className="group-26" src="/img/group-26@2x.svg" alt="Group 26" />
          </Link>
          <div className="avanar balooda2-normal-white-24px">{avanar}</div>
          <Link to="/frame-1">
            <div className="group-28">
              <div className="overlap-group-65">
                <div className="voltar-3 balooda2-normal-white-24px-2">{voltar}</div>
              </div>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default Frame3;
