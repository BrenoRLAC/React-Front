import React from "react";
import { Link } from "react-router-dom";
import Group139 from "../Group139";
import Group53 from "../Group53";
import "./Frame32.css";

function Frame32(props) {
  const {
    configuraes,
    pginaInicial,
    sair,
    rectangle190,
    skybank,
    cep,
    text21,
    nomeDaRuaAvenida,
    number,
    endereo1,
    nmero,
    complemento,
    opcional,
    nomeDoBairro,
    sala0,
    bairro,
    endereo2,
    altereSeuEndereoOuAdicioneOutro,
    voltar,
    olNomeDoUsuario,
    group53Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-32 screen">
        <div className="overlap-group4-16">
          <div className="rectangle-183"></div>
          <div className="rectangle-184"></div>
          <div className="rectangle-185"></div>
          <div className="configuraes-12 balooda-regular-normal-picton-blue-20px">{configuraes}</div>
          <img className="config_icone-11" src="/img/config-icone-11@2x.svg" alt="Config_icone" />
          <div className="rectangle-186-4"></div>
          <Link to="/frame-2">
            <div className="group-152-1">
              <div className="overlap-group-56">
                <div className="rectangle-46-11"></div>
                <img className="line-9-11" src="/img/line-9-11@2x.svg" alt="Line 9" />
                <div className="rectangle-47-11"></div>
                <div className="rectangle-48-11"></div>
                <img className="line-10-11" src="/img/line-10@2x.svg" alt="Line 10" />
                <img className="line-11-11" src="/img/line-11@2x.svg" alt="Line 11" />
              </div>
              <div className="pgina-inicial-12 balooda-regular-normal-cape-cod-20px">{pginaInicial}</div>
            </div>
          </Link>
          <a href="javascript:ShowOverlay('frame-5', 'animate-appear');">
            <div className="group-55-3">
              <div className="overlap-group-57">
                <div className="rectangle-180-11"></div>
                <img className="line-32-11" src="/img/line-32@2x.svg" alt="Line 32" />
                <img className="line-31-11" src="/img/line-31@2x.svg" alt="Line 31" />
                <img className="vector-19-12" src="/img/vector-19@2x.svg" alt="Vector 19" />
              </div>
              <div className="sair-11 balooda-regular-normal-cape-cod-20px">{sair}</div>
            </div>
          </a>
          <img className="line-37-4" src="/img/line-37@2x.svg" alt="Line 37" />
          <img className="line-38-4" src="/img/line-37@2x.svg" alt="Line 38" />
          <img className="line-39-4" src="/img/line-37@2x.svg" alt="Line 39" />
          <img className="rectangle-190-4" src={rectangle190} alt="Rectangle 190" />
          <div className="sky-bank-13 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
          <div className="overlap-group1-28">
            <Group139 />
            <div className="cep-2 balooda2-semi-bold-cape-cod-32px">{cep}</div>
            <div className="text-21 balooda2-normal-silver-chalice-32px">{text21}</div>
            <div className="nome-da-ruaavenida balooda2-normal-silver-chalice-32px">{nomeDaRuaAvenida}</div>
            <div className="number-6 balooda2-normal-silver-chalice-32px">{number}</div>
            <div className="endereo-4 balooda2-semi-bold-cape-cod-32px">{endereo1}</div>
            <div className="nmero-8 balooda2-semi-bold-cape-cod-32px">{nmero}</div>
            <div className="complemento-2 balooda2-semi-bold-cape-cod-32px">{complemento}</div>
            <div className="opcional balooda2-semi-bold-cape-cod-20px">{opcional}</div>
          </div>
          <a href="javascript:ShowOverlay('frame-34', 'animate-appear');">
            <div className="group-161">
              <img className="group-15" src="/img/group-157@2x.svg" alt="Group 157" />
            </div>
          </a>
          <a href="javascript:ShowOverlay('frame-35', 'animate-appear');">
            <div className="group-160">
              <img className="group-15" src="/img/group-157@2x.svg" alt="Group 158" />
            </div>
          </a>
          <a href="javascript:ShowOverlay('frame-36', 'animate-appear');">
            <div className="group-165">
              <img className="group-15" src="/img/group-157@2x.svg" alt="Group 158" />
            </div>
          </a>
          <a href="javascript:ShowOverlay('frame-37', 'animate-appear');">
            <div className="group-162">
              <img className="group-15" src="/img/group-159@2x.svg" alt="Group 159" />
            </div>
          </a>
          <div className="nome-do-bairro balooda2-normal-silver-chalice-32px">{nomeDoBairro}</div>
          <div className="sala-0 balooda2-normal-silver-chalice-32px">{sala0}</div>
          <div className="bairro-2 balooda2-semi-bold-cape-cod-32px">{bairro}</div>
          <a href="javascript:ShowOverlay('frame-38', 'animate-appear');">
            <div className="group-164">
              <img className="group-15" src="/img/group-159@2x.svg" alt="Group 159" />
            </div>
          </a>
          <div className="overlap-group2-20">
            <div className="endereo-container-1">
              <div className="endereo-5 balooda-regular-normal-cape-cod-34px">{endereo2}</div>
              <p className="altere-seu-endereo-ou-adicione-outro-1 balooda2-normal-cape-cod-24px">
                {altereSeuEndereoOuAdicioneOutro}
              </p>
            </div>
            <Link to="/frame-27">
              <div className="voltar-1 balooda2-normal-dodger-blue-24px">{voltar}</div>
            </Link>
          </div>
          <div className="ellipse-62-1"></div>
          <div className="ellipse-container-4">
            <div className="ellipse-63-17"></div>
            <img className="ellipse-68" src="/img/ellipse-68@2x.svg" alt="Ellipse 68" />
          </div>
          <div className="rectangle-187"></div>
          <div className="ol-nome-do-usuario-12 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          <Group53 className={group53Props.className} />
        </div>
      </div>
    </div>
  );
}

export default Frame32;
