import React from "react";
import "./Group53.css";

function Group53(props) {
  const { className } = props;

  return (
    <div className={`group-53 ${className || ""}`}>
      <div className="ellipse-63-2"></div>
      <img className="ellipse-64-1" src="/img/ellipse-64@2x.svg" alt="Ellipse 64" />
    </div>
  );
}

export default Group53;
