import React from "react";
import { Link } from "react-router-dom";
import Component1 from "../Component1";
import "./Frame1.css";

function Frame1(props) {
  const {
    investindoComASkybankOCuOLimite,
    group170,
    overlapGroup1,
    entrar,
    cpf,
    senha,
    noTemUmaConta,
    cadastreSe1,
    aindaNoTemUmaConta,
    cadastreSe2,
    component1Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-1 screen">
        <div className="overlap-group-container">
          <div className="overlap-group2">
            <img
              className="investindo-com-a-sky-bank-o-cu-o-limite"
              src={investindoComASkybankOCuOLimite}
              alt="Investindo com a SkyBank, o cu  o limite"
            />
            <img className="group-170" src={group170} alt="Group 170" />
          </div>
          <div className="overlap-group1" style={{ backgroundImage: `url(${overlapGroup1})` }}>
            <div className="entrar balooda-regular-normal-cape-cod-36px">{entrar}</div>
            <div className="cpf balooda2-normal-silver-chalice-20px">{cpf}</div>
            <img className="line-18" src="/img/line-18@2x.svg" alt="Line 18" />
            <div className="overlap-group5">
              <div className="senha balooda2-normal-silver-chalice-20px">{senha}</div>
              <img className="line-19" src="/img/line-19@2x.svg" alt="Line 19" />
            </div>
            <div className="overlap-group3">
              <div className="no-tem-uma-conta">{noTemUmaConta}</div>
              <Link to="/frame-3">
                <div className="cadastre-se">{cadastreSe1}</div>
              </Link>
              <Component1>{component1Props.children}</Component1>
            </div>
            <div className="overlap-group4">
              <p className="ainda-no-tem-uma-conta">{aindaNoTemUmaConta}</p>
              <Link to="/frame-3">
                <div className="cadastre-se-1">{cadastreSe2}</div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame1;
