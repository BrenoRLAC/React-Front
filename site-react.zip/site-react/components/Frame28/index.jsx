import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import Group139 from "../Group139";
import "./Frame28.css";

function Frame28(props) {
  const {
    configuraes,
    pginaInicial,
    olNomeDoUsuario,
    sair,
    rectangle190,
    skybank,
    place,
    nomeDoUsuario,
    address,
    text23,
    number,
    price,
    nmero,
    validade,
    cvv,
    seuCarto,
    gerencieSeuCarto,
    voltar,
    fatura,
    group53Props,
    group139Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-28 screen">
        <div className="overlap-group3-20">
          <div className="rectangle-183-1"></div>
          <div className="rectangle-184-1"></div>
          <div className="rectangle-185-1"></div>
          <div className="configuraes-14 balooda-regular-normal-picton-blue-20px">{configuraes}</div>
          <img className="config_icone-13" src="/img/config-icone-13@2x.svg" alt="Config_icone" />
          <div className="rectangle-186-5"></div>
          <Link to="/frame-2">
            <div className="group-152-2">
              <div className="overlap-group-62">
                <div className="rectangle-46-13"></div>
                <img className="line-9-13" src="/img/line-9@2x.svg" alt="Line 9" />
                <div className="rectangle-47-13"></div>
                <div className="rectangle-48-13"></div>
                <img className="line-10-13" src="/img/line-10@2x.svg" alt="Line 10" />
                <img className="line-11-13" src="/img/line-11@2x.svg" alt="Line 11" />
              </div>
              <div className="pgina-inicial-14 balooda-regular-normal-cape-cod-20px">{pginaInicial}</div>
            </div>
          </Link>
          <div className="rectangle-187-1"></div>
          <div className="ol-nome-do-usuario-14 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          <Group53 className={group53Props.className} />
          <a href="javascript:ShowOverlay('frame-5', 'animate-appear');">
            <div className="group-55-4">
              <div className="overlap-group-63">
                <div className="rectangle-180-13"></div>
                <img className="line-32-13" src="/img/line-32@2x.svg" alt="Line 32" />
                <img className="line-31-13" src="/img/line-31@2x.svg" alt="Line 31" />
                <img className="vector-19-14" src="/img/vector-19@2x.svg" alt="Vector 19" />
              </div>
              <div className="sair-13 balooda-regular-normal-cape-cod-20px">{sair}</div>
            </div>
          </a>
          <img className="line-37-5" src="/img/line-37@2x.svg" alt="Line 37" />
          <img className="line-38-5" src="/img/line-37@2x.svg" alt="Line 38" />
          <img className="line-39-5" src="/img/line-37@2x.svg" alt="Line 39" />
          <img className="rectangle-190-5" src={rectangle190} alt="Rectangle 190" />
          <div className="sky-bank-15 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
          <div className="overlap-group1-30">
            <Group139 className={group139Props.className} />
            <div className="place-7 balooda2-semi-bold-cape-cod-32px">{place}</div>
            <div className="nome-do-usuario-13 balooda2-normal-silver-chalice-32px">{nomeDoUsuario}</div>
            <div className="address-6 balooda2-normal-silver-chalice-32px">{address}</div>
            <div className="text-23 balooda2-normal-silver-chalice-32px">{text23}</div>
            <div className="number-7 balooda2-semi-bold-silver-chalice-32px">{number}</div>
            <div className="price-15 balooda2-semi-bold-silver-chalice-32px">{price}</div>
            <div className="nmero-9 balooda2-semi-bold-cape-cod-32px">{nmero}</div>
            <div className="validade-6 balooda2-semi-bold-cape-cod-32px">{validade}</div>
            <div className="cvv balooda2-semi-bold-cape-cod-32px">{cvv}</div>
          </div>
          <div className="overlap-group2-22">
            <div className="overlap-group-64">
              <div className="group-90">
                <img className="line-52-16" src="/img/line-52@2x.svg" alt="Line 52" />
                <img className="line-53-10" src="/img/line-52@2x.svg" alt="Line 53" />
                <div className="line-container-5">
                  <img className="line-5-5" src="/img/line-54-10@2x.svg" alt="Line 54" />
                  <img className="line-5-5" src="/img/line-54-10@2x.svg" alt="Line 55" />
                </div>
              </div>
            </div>
            <div className="seu-carto-container-1">
              <div className="seu-carto-1 balooda-regular-normal-cape-cod-34px">{seuCarto}</div>
              <div className="gerencie-seu-carto-1 balooda2-normal-cape-cod-24px">{gerencieSeuCarto}</div>
            </div>
            <Link to="/frame-27">
              <div className="voltar-2 balooda2-normal-dodger-blue-24px">{voltar}</div>
            </Link>
          </div>
          <a href="javascript:ShowOverlay('frame-31', 'animate-appear');">
            <div className="group-167">
              <div className="fatura-1 valign-text-middle">{fatura}</div>
              <img className="vector-20-1" src="/img/vector-20-1@2x.svg" alt="Vector 20" />
            </div>
          </a>
        </div>
      </div>
    </div>
  );
}

export default Frame28;
