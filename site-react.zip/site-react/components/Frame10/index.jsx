import React from "react";
import { Link } from "react-router-dom";
import "./Frame10.css";

function Frame10(props) {
  const { children } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-10 screen" onclick="window.open('frame-2.html', '_self');">
        <div className="overlap-group">
          <h1 className="estamos-preparando-tudo-para-voc barlow-normal-white-64px">{children}</h1>
        </div>
      </div>
    </div>
  );
}

export default Frame10;
