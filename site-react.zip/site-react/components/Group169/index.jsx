import React from "react";
import "./Group169.css";

function Group169(props) {
  const { className } = props;

  return (
    <div className={`group-169 ${className || ""}`}>
      <div className="overlap-group1-25">
        <div className="salvar-2 balooda2-normal-white-24px">Salvar</div>
      </div>
    </div>
  );
}

export default Group169;
