import React from "react";
import "./Frame31.css";

function Frame31(props) {
  const { fatura, price, pagarFatura } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-31 screen">
        <div className="flex-row-32">
          <div className="overlap-group1-22">
            <img className="line-73-1" src="/img/line-73-1@2x.svg" alt="Line 73" />
          </div>
          <div className="fatura balooda-regular-normal-cape-cod-48px">{fatura}</div>
        </div>
        <img className="line-52-10" src="/img/line-52-10@1x.svg" alt="Line 52" />
        <div className="overlap-group-container-28">
          <div className="overlap-group2-15">
            <div className="price-8">{price}</div>
            <img className="line-69-2" src="/img/line-66@2x.svg" alt="Line 69" />
          </div>
          <div className="overlap-group-38">
            <div className="pagar-fatura balooda2-normal-white-24px">{pagarFatura}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame31;
