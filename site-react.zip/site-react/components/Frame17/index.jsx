import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import Group24 from "../Group24";
import Group97 from "../Group97";
import Group85 from "../Group85";
import Group84 from "../Group84";
import "./Frame17.css";

function Frame17(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    sair,
    rectangle199,
    skybank,
    conta,
    text11,
    transferir,
    depositar,
    atividade,
    nomeDoUsuario,
    place,
    address,
    nmero,
    copiar,
    text12,
    validade,
    number,
    cvc,
    suaAtividade,
    vocFezUmaTransferncia,
    r20000,
    hoje,
    vocRecebeuUmaTransferncia,
    r15000,
    ontem,
    group24Props,
    group97Props,
    group85Props,
    group84Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-17 screen">
        <div className="overlap-group11-5">
          <div className="overlap-group14-3">
            <Group53 />
            <div className="ol-nome-do-usuario-6 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-21">
            <div className="overlap-group13-5">
              <div className="flex-row-20">
                <div className="rectangle-195-1"></div>
                <div className="overlap-group-30">
                  <div className="rectangle-46-6"></div>
                  <img className="line-9-6" src="/img/line-9-1@2x.svg" alt="Line 9" />
                  <div className="rectangle-47-6"></div>
                  <div className="rectangle-48-6"></div>
                  <img className="line-10-6" src="/img/line-10-6@2x.svg" alt="Line 10" />
                  <img className="line-11-6" src="/img/line-11-6@2x.svg" alt="Line 11" />
                </div>
                <div className="pgina-inicial-6 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-151">
                  <img className="config_icone-6" src="/img/config-icone-6@2x.svg" alt="Config_icone" />
                  <div className="configuraes-6 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-42-1" src="/img/line-37@2x.svg" alt="Line 42" />
              <img className="line-41-1" src="/img/line-37@2x.svg" alt="Line 41" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-53-5">
                  <div className="overlap-group-31">
                    <div className="rectangle-180-6"></div>
                    <img className="line-32-6" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31-6" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19-7" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair-6 balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-43-1" src="/img/line-37@2x.svg" alt="Line 43" />
              <div className="flex-row-21">
                <img className="rectangle-199-1" src={rectangle199} alt="Rectangle 199" />
                <div className="sky-bank-7 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group12-5">
              <div className="overlap-group-container-22">
                <div className="overlap-group15-3">
                  <div className="flex-row-22">
                    <div className="flex-col-8">
                      <div className="overlap-group3-9">
                        <div className="conta-5 balooda2-normal-cape-cod-36px">{conta}</div>
                        <div className="text-11 balooda-regular-normal-cape-cod-56px">{text11}</div>
                      </div>
                      <Group24 className={group24Props.className} />
                      <div className="transferir-11 balooda-regular-normal-cape-cod-20px">{transferir}</div>
                    </div>
                    <div className="flex-col-9">
                      <div className="group-23-5">
                        <div className="overlap-group-28">
                          <div className="rectangle-16-1"></div>
                          <div className="ellipse-54-11"></div>
                          <div className="rectangle-162-11"></div>
                          <img className="polygon-7-12" src="/img/polygon-7@2x.svg" alt="Polygon 7" />
                        </div>
                      </div>
                      <div className="depositar-11 balooda-regular-normal-cape-cod-20px">{depositar}</div>
                    </div>
                  </div>
                  <img className="line-44-1" src="/img/line-61@1x.svg" alt="Line 44" />
                  <Link to="/frame-15">
                    <div className="group-57-2">
                      <div className="overlap-group7-7">
                        <img className="ellipse-13-2" src="/img/ellipse-13-2@2x.svg" alt="Ellipse 13" />
                        <img className="line-5-2" src="/img/line-5-2@2x.svg" alt="Line 5" />
                        <img className="line-7-2" src="/img/line-7-2@2x.svg" alt="Line 7" />
                        <img className="line-8-2" src="/img/line-8-2@2x.svg" alt="Line 8" />
                        <img className="line-6-2" src="/img/line-6@2x.svg" alt="Line 6" />
                      </div>
                    </div>
                  </Link>
                  <div className="atividade-5 balooda-regular-normal-picton-blue-20px-3">{atividade}</div>
                  <Link to="/frame-25">
                    <div className="group-95">
                      <div className="overlap-group-28">
                        <div className="rectangle-16-1"></div>
                        <div className="ellipse-54-11"></div>
                        <div className="rectangle-162-11"></div>
                        <img className="polygon-7-12" src="/img/polygon-7-1@2x.svg" alt="Polygon 7" />
                      </div>
                    </div>
                  </Link>
                  <Link to="/frame-22">
                    <div className="group-96">
                      <div className="overlap-group9-6">
                        <div className="rectangle-16-1"></div>
                        <div className="ellipse-55-18"></div>
                        <div className="rectangle-164-18"></div>
                        <img className="polygon-8-18" src="/img/polygon-8@2x.svg" alt="Polygon 8" />
                      </div>
                    </div>
                  </Link>
                  <Group97 group87Props={group97Props.group87Props} />
                </div>
                <div className="overlap-group16-2">
                  <div className="overlap-group4-9">
                    <div className="overlap-group1-18">
                      <div className="nome-do-usuario-6 balooda2-bold-white-24px">{nomeDoUsuario}</div>
                      <div className="place-4 balooda2-normal-white-16px">{place}</div>
                    </div>
                    <div className="flex-row-23">
                      <div className="overlap-group5-7">
                        <div className="address-3 balooda2-bold-white-24px">{address}</div>
                        <div className="nmero-4 balooda2-normal-white-16px">{nmero}</div>
                      </div>
                      <div className="overlap-group6-5">
                        <div className="rectangle-175-3"></div>
                        <div className="line-container-2">
                          <img className="line-20-4" src="/img/line-20-2@2x.svg" alt="Line 20" />
                          <img className="line-21-2" src="/img/line-21@2x.svg" alt="Line 21" />
                        </div>
                      </div>
                      <div className="copiar-3 balooda2-bold-white-16px">{copiar}</div>
                      <Link to="/frame-16">
                        <img className="vector-18-5" src="/img/vector-18-2@2x.svg" alt="Vector 18" />
                      </Link>
                    </div>
                    <div className="overlap-group-container-23">
                      <div className="overlap-group-29">
                        <div className="text-12 balooda2-bold-white-20px">{text12}</div>
                        <div className="validade-3 balooda2-normal-white-16px">{validade}</div>
                      </div>
                      <div className="overlap-group-29">
                        <div className="number-3 balooda2-bold-white-20px">{number}</div>
                        <div className="cvc-3 balooda2-normal-white-16px">{cvc}</div>
                      </div>
                    </div>
                    <div className="rectangle-176-3"></div>
                  </div>
                </div>
              </div>
              <div className="overlap-group10-6">
                <div className="flex-col-10">
                  <div className="overlap-group4-10">
                    <div className="sua-atividade-1 balooda2-normal-cape-cod-24px">{suaAtividade}</div>
                    <img className="line-43-2" src="/img/line-43-2@1x.svg" alt="Line 43" />
                  </div>
                  <div className="flex-row-24">
                    <Group85 className={group85Props.className} />
                    <div className="voc-fez-uma-transferncia-3 balooda2-normal-cape-cod-28px">
                      {vocFezUmaTransferncia}
                    </div>
                    <div className="overlap-group2-12">
                      <div className="r-20000-1 balooda2-normal-flush-mahogany-24px">{r20000}</div>
                      <div className="hoje-1 balooda2-normal-nobel-24px">{hoje}</div>
                    </div>
                  </div>
                  <img className="line-4" src="/img/line-49@1x.svg" alt="Line 44" />
                </div>
                <div className="flex-row-25">
                  <Group84 className={group84Props.className} />
                  <div className="voc-recebeu-uma-transferncia-1 balooda2-normal-cape-cod-28px">
                    {vocRecebeuUmaTransferncia}
                  </div>
                  <div className="overlap-group3-10">
                    <div className="r-15000-1 balooda2-normal-fern-24px">{r15000}</div>
                    <div className="ontem-1 balooda2-normal-nobel-24px">{ontem}</div>
                  </div>
                </div>
                <img className="line-4" src="/img/line-49@1x.svg" alt="Line 45" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame17;
