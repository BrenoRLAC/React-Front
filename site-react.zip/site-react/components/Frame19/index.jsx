import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import "./Frame19.css";

function Frame19(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    sair,
    rectangle172,
    skybank,
    conta,
    price1,
    group89,
    atividade,
    group88,
    transferir1,
    group23,
    depositar,
    cartoDeCrdito,
    faturaAtual,
    text20,
    nomeDoUsuario,
    limiteDisponvelDeR178010,
    rectangle70,
    transferir2,
    qualOValorDa,
    transferncia,
    nomeCpfCnpj,
    spanText1,
    spanText2,
    price2,
    transferir3,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-19 screen">
        <div className="overlap-group6-9">
          <div className="overlap-group9-11">
            <Group53 />
            <div className="ol-nome-do-usuario-11 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-36">
            <div className="overlap-group7-10">
              <div className="flex-row-54">
                <div className="rectangle-175-7"></div>
                <div className="overlap-group-52">
                  <div className="rectangle-46-10"></div>
                  <img className="line-9-10" src="/img/line-9-5@2x.svg" alt="Line 9" />
                  <div className="rectangle-47-10"></div>
                  <div className="rectangle-48-10"></div>
                  <img className="line-10-10" src="/img/line-10-10@2x.svg" alt="Line 10" />
                  <img className="line-11-10" src="/img/line-11-10@2x.svg" alt="Line 11" />
                </div>
                <div className="pgina-inicial-11 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-143">
                  <img className="config_icone-10" src="/img/config-icone-10@2x.svg" alt="Config_icone" />
                  <div className="configuraes-11 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-35-2" src="/img/line-37@2x.svg" alt="Line 35" />
              <img className="line-33-2" src="/img/line-37@2x.svg" alt="Line 33" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-98-2">
                  <div className="overlap-group-53">
                    <div className="rectangle-180-10"></div>
                    <img className="line-32-10" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31-10" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19-11" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair-10 balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-34-2" src="/img/line-37@2x.svg" alt="Line 34" />
              <div className="flex-row-55">
                <img className="rectangle-172-2" src={rectangle172} alt="Rectangle 172" />
                <div className="sky-bank-12 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group8-9">
              <div className="overlap-group-container-37">
                <div className="overlap-group10-10">
                  <div className="overlap-group12-10">
                    <div className="group-container-11">
                      <div className="overlap-group-54">
                        <div className="conta-10 balooda2-normal-cape-cod-36px">{conta}</div>
                        <div className="price-11 balooda-regular-normal-cape-cod-56px">{price1}</div>
                      </div>
                      <Link to="/frame-21">
                        <div className="group-21-4">
                          <div className="ellipse-container-3">
                            <div className="ellipse-56-3"></div>
                            <img className="ellipse-58-3" src="/img/ellipse-58-3@2x.svg" alt="Ellipse 58" />
                          </div>
                        </div>
                      </Link>
                    </div>
                    <img className="line-36-2" src="/img/line-61@1x.svg" alt="Line 36" />
                  </div>
                  <div className="flex-row-56">
                    <div className="flex-col-22">
                      <Link to="/frame-2">
                        <img className="group" src={group89} alt="Group 89" />
                      </Link>
                      <div className="atividade-10 balooda-regular-normal-cape-cod-20px">{atividade}</div>
                    </div>
                    <div className="flex-col-23">
                      <img className="group-88-2" src={group88} alt="Group 88" />
                      <div className="transferir-16 balooda-regular-normal-picton-blue-20px-2">{transferir1}</div>
                    </div>
                    <div className="flex-col-24">
                      <Link to="/frame-23">
                        <img className="group" src={group23} alt="Group 23" />
                      </Link>
                      <div className="depositar-19 balooda-regular-normal-cape-cod-20px">{depositar}</div>
                    </div>
                  </div>
                </div>
                <div className="overlap-group11-10">
                  <div className="rectangle-60-4"></div>
                  <div className="carto-de-crdito-4 balooda-regular-normal-white-32px">{cartoDeCrdito}</div>
                  <Link to="/frame-28">
                    <p className="fatura-atual-4 balooda2-medium-white-16px">{faturaAtual}</p>
                  </Link>
                  <div className="text-20 balooda2-medium-white-16px">{text20}</div>
                  <div className="nome-do-usuario-11 balooda2-medium-white-16px">{nomeDoUsuario}</div>
                  <div className="limite-disponvel-de-r178010-1 balooda2-medium-white-16px">
                    {limiteDisponvelDeR178010}
                  </div>
                  <img className="x-1" src="/img/----@2x.svg" alt="****" />
                  <Link to="/frame-20">
                    <img className="vector-17-4" src="/img/vector-17@2x.svg" alt="Vector 17" />
                  </Link>
                  <img className="rectangle-70-4" src={rectangle70} alt="Rectangle 70" />
                </div>
              </div>
              <div className="overlap-group3-17 balooda2-normal-cape-cod-24px">
                <div className="overlap-group5-9">
                  <div className="transferir-17">{transferir2}</div>
                  <img className="line-3" src="/img/line-49@1x.svg" alt="Line 52" />
                  <img className="line-3" src="/img/line-49@1x.svg" alt="Line 65" />
                </div>
                <div className="overlap-group-container-38">
                  <div className="overlap-group-55 balooda-regular-normal-cape-cod-56px">
                    <p className="qual-o-valor-da-3">{qualOValorDa}</p>
                    <div className="transferncia-3">{transferncia}</div>
                  </div>
                  <div className="overlap-group4-15">
                    <img className="line-64" src="/img/line-70@2x.svg" alt="Line 64" />
                    <div className="nome-cpfcnpj-3 balooda2-normal-pink-swan-36px">{nomeCpfCnpj}</div>
                  </div>
                </div>
                <p className="saldo-disponvel-em-conta-r-250000-1">
                  <span className="balooda2-normal-cape-cod-24px">{spanText1}</span>
                  <span className="balooda2-bold-cape-cod-24px">{spanText2}</span>
                </p>
                <div className="overlap-group-container-39">
                  <div className="overlap-group2-19">
                    <div className="price-12 balooda-regular-normal-cape-cod-56px">{price2}</div>
                    <img className="line-20-8" src="/img/line-69@2x.svg" alt="Line 20" />
                  </div>
                  <div className="overlap-group1-27">
                    <div className="transferir-18 balooda2-normal-white-24px">{transferir3}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame19;
