import React from "react";
import { Link } from "react-router-dom";
import Group24 from "../Group24";
import Group85 from "../Group85";
import Group84 from "../Group84";
import "./Frame16.css";

function Frame16(props) {
  const {
    group53,
    olNomeDoUsuario,
    iconHome,
    pginaInicial,
    iconSettings,
    configuraes,
    sair,
    rectangle190,
    skybank,
    conta,
    text17,
    transferir,
    depositar,
    atividade,
    cartoDeCrdito,
    faturaAtual,
    text16,
    nomeDoUsuario,
    limiteDisponvelDe,
    rectangle70,
    text18,
    suaAtividade,
    vocFezUmaTransferncia,
    r20000,
    hoje,
    vocRecebeuUmaTransferncia,
    r15000,
    ontem,
    group24Props,
    group85Props,
    group84Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-16 screen">
        <div className="overlap-group9-9">
          <div className="overlap-group12-8">
            <img className="group-53-7" src={group53} alt="Group 53" />
            <div className="ol-nome-do-usuario-9 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-31">
            <div className="overlap-group11-8">
              <div className="flex-row-43">
                <div className="rectangle-186-2"></div>
                <img className="icon-home" src={iconHome} alt="icon-home" />
                <div className="pgina-inicial-9 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-140">
                  <img className="icon-settings" src={iconSettings} alt="icon-settings" />
                  <div className="configuraes-9 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-38-2" src="/img/line-37@2x.svg" alt="Line 38" />
              <img className="line-37-2" src="/img/line-37@2x.svg" alt="Line 37" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-55-2">
                  <div className="overlap-group-46">
                    <div className="rectangle-180-8"></div>
                    <img className="line-32-8" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31-8" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19-9" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair-8 balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-39-2" src="/img/line-37@2x.svg" alt="Line 39" />
              <div className="flex-row-44">
                <img className="rectangle-190-2" src={rectangle190} alt="Rectangle 190" />
                <div className="sky-bank-10 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group10-8">
              <div className="overlap-group-container-32">
                <div className="overlap-group13-8">
                  <div className="flex-row-45">
                    <div className="flex-col-16">
                      <div className="overlap-group3-14">
                        <div className="conta-8 balooda2-normal-cape-cod-36px">{conta}</div>
                        <div className="text-17 balooda-regular-normal-cape-cod-56px">{text17}</div>
                      </div>
                      <Group24 className={group24Props.className} />
                      <div className="transferir-14 balooda-regular-normal-cape-cod-20px">{transferir}</div>
                    </div>
                    <div className="flex-col-17">
                      <div className="group-23-8">
                        <div className="overlap-group-45">
                          <div className="rectangle-16-3"></div>
                          <div className="ellipse-54-14"></div>
                          <div className="rectangle-162-14"></div>
                          <img className="polygon-7-15" src="/img/polygon-7@2x.svg" alt="Polygon 7" />
                        </div>
                      </div>
                      <div className="depositar-17 balooda-regular-normal-cape-cod-20px">{depositar}</div>
                    </div>
                  </div>
                  <img className="line-40-2" src="/img/line-61@1x.svg" alt="Line 40" />
                  <Link to="/frame-2">
                    <div className="group-46">
                      <div className="overlap-group4-12">
                        <img className="ellipse-13-4" src="/img/ellipse-13-4@2x.svg" alt="Ellipse 13" />
                        <img className="line-5-4" src="/img/line-5-2@2x.svg" alt="Line 5" />
                        <img className="line-7-4" src="/img/line-7-2@2x.svg" alt="Line 7" />
                        <img className="line-8-4" src="/img/line-8-2@2x.svg" alt="Line 8" />
                        <img className="line-6-4" src="/img/line-6@2x.svg" alt="Line 6" />
                      </div>
                    </div>
                  </Link>
                  <div className="atividade-8 balooda-regular-normal-picton-blue-20px-3">{atividade}</div>
                  <Link to="/frame-26">
                    <div className="group-95-1">
                      <div className="overlap-group-45">
                        <div className="rectangle-16-3"></div>
                        <div className="ellipse-54-14"></div>
                        <div className="rectangle-162-14"></div>
                        <img className="polygon-7-15" src="/img/polygon-7-1@2x.svg" alt="Polygon 7" />
                      </div>
                    </div>
                  </Link>
                  <Link to="/frame-21">
                    <div className="group-96-1">
                      <div className="overlap-group6-7">
                        <div className="rectangle-16-3"></div>
                        <div className="ellipse-55-21"></div>
                        <div className="rectangle-164-21"></div>
                        <img className="polygon-8-21" src="/img/polygon-8@2x.svg" alt="Polygon 8" />
                      </div>
                    </div>
                  </Link>
                  <div className="group-97-1">
                    <div className="group-87-2">
                      <img className="line-52-15" src="/img/line-52-13@2x.svg" alt="Line 52" />
                      <img className="line-53-9" src="/img/line-53-8@2x.svg" alt="Line 53" />
                      <img className="line-54-9" src="/img/line-53-7@2x.svg" alt="Line 54" />
                    </div>
                  </div>
                </div>
                <div className="overlap-group15-6">
                  <div className="overlap-group-47">
                    <div className="rectangle-60-3"></div>
                    <div className="carto-de-crdito-3 balooda-regular-normal-white-32px">{cartoDeCrdito}</div>
                    <Link to="/frame-28">
                      <p className="fatura-atual-3 balooda2-medium-white-16px">{faturaAtual}</p>
                    </Link>
                    <div className="text-16 balooda2-medium-white-16px">{text16}</div>
                    <div className="nome-do-usuario-9 balooda2-medium-white-16px">{nomeDoUsuario}</div>
                    <p className="limite-disponvel-de-2 balooda2-medium-white-16px">{limiteDisponvelDe}</p>
                    <Link to="/frame-17">
                      <img className="vector-17-3" src="/img/vector-17@2x.svg" alt="Vector 17" />
                    </Link>
                    <img className="rectangle-70-3" src={rectangle70} alt="Rectangle 70" />
                  </div>
                  <div className="rectangle-189"></div>
                  <div className="text-18 balooda2-bold-white-36px">{text18}</div>
                </div>
              </div>
              <div className="overlap-group14-6">
                <div className="flex-col-18">
                  <div className="overlap-group17-3">
                    <div className="sua-atividade-3 balooda2-normal-cape-cod-24px">{suaAtividade}</div>
                    <img className="line-46" src="/img/line-43-2@1x.svg" alt="Line 46" />
                  </div>
                  <div className="flex-row-46">
                    <Group85 className={group85Props.className} />
                    <div className="voc-fez-uma-transferncia-5 balooda2-normal-cape-cod-28px">
                      {vocFezUmaTransferncia}
                    </div>
                    <div className="overlap-group16-5">
                      <div className="r-20000-3 balooda2-normal-flush-mahogany-24px">{r20000}</div>
                      <div className="hoje-3 balooda2-normal-nobel-24px">{hoje}</div>
                    </div>
                  </div>
                  <img className="line-4-2" src="/img/line-49@1x.svg" alt="Line 47" />
                </div>
                <div className="flex-row-47">
                  <Group84 className={group84Props.className} />
                  <div className="voc-recebeu-uma-transferncia-3 balooda2-normal-cape-cod-28px">
                    {vocRecebeuUmaTransferncia}
                  </div>
                  <div className="overlap-group18-2">
                    <div className="r-15000-3 balooda2-normal-fern-24px">{r15000}</div>
                    <div className="ontem-3 balooda2-normal-nobel-24px">{ontem}</div>
                  </div>
                </div>
                <img className="line-4-2" src="/img/line-49@1x.svg" alt="Line 48" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame16;
