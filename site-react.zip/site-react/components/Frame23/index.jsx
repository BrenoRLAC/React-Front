import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import Group87 from "../Group87";
import Group23 from "../Group23";
import "./Frame23.css";

function Frame23(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    sair,
    rectangle172,
    skybank,
    conta,
    price1,
    atividade,
    transferir,
    depositar1,
    cartoDeCrdito,
    faturaAtual,
    text22,
    nomeDoUsuario,
    limiteDisponvelDeR178010,
    rectangle70,
    depositar2,
    qualValorVocQuer,
    depositar3,
    price2,
    depositar4,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-23 screen">
        <div className="overlap-group6-10">
          <div className="overlap-group9-12">
            <Group53 />
            <div className="ol-nome-do-usuario-13 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-40">
            <div className="overlap-group8-10">
              <div className="flex-row-57">
                <div className="rectangle-175-8"></div>
                <div className="overlap-group-58">
                  <div className="rectangle-46-12"></div>
                  <img className="line-9-12" src="/img/line-9-3@2x.svg" alt="Line 9" />
                  <div className="rectangle-47-12"></div>
                  <div className="rectangle-48-12"></div>
                  <img className="line-10-12" src="/img/line-10-12@2x.svg" alt="Line 10" />
                  <img className="line-11-12" src="/img/line-11-12@2x.svg" alt="Line 11" />
                </div>
                <div className="pgina-inicial-13 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-147">
                  <img className="config_icone-12" src="/img/config-icone-12@2x.svg" alt="Config_icone" />
                  <div className="configuraes-13 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-35-3" src="/img/line-37@2x.svg" alt="Line 35" />
              <img className="line-33-3" src="/img/line-37@2x.svg" alt="Line 33" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-98-3">
                  <div className="overlap-group-59">
                    <div className="rectangle-180-12"></div>
                    <img className="line-32-12" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31-12" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19-13" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair-12 balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-34-3" src="/img/line-37@2x.svg" alt="Line 34" />
              <div className="flex-row-58">
                <img className="rectangle-172-3" src={rectangle172} alt="Rectangle 172" />
                <div className="sky-bank-14 balootammudu2-semi-bold-dodger-blue-30px">{skybank}</div>
              </div>
            </div>
            <div className="overlap-group7-11">
              <div className="overlap-group-container-41">
                <div className="overlap-group10-11">
                  <div className="overlap-group12-11">
                    <div className="group-container-12">
                      <div className="overlap-group-60">
                        <div className="conta-11 balooda2-normal-cape-cod-36px">{conta}</div>
                        <div className="price-13 balooda-regular-normal-cape-cod-56px">{price1}</div>
                      </div>
                      <Link to="/frame-26">
                        <div className="group-21-5">
                          <div className="ellipse-container-5">
                            <div className="ellipse-56-4"></div>
                            <img className="ellipse-58-4" src="/img/ellipse-58-4@2x.svg" alt="Ellipse 58" />
                          </div>
                        </div>
                      </Link>
                    </div>
                    <img className="line-36-3" src="/img/line-61@1x.svg" alt="Line 36" />
                  </div>
                  <div className="flex-row-59">
                    <div className="flex-col-25">
                      <Link to="/frame-2">
                        <div className="group-89-2">
                          <Group87 />
                        </div>
                      </Link>
                      <div className="atividade-11 balooda-regular-normal-cape-cod-20px">{atividade}</div>
                    </div>
                    <div className="flex-col-26">
                      <Link to="/frame-19">
                        <div className="group-88-3">
                          <div className="overlap-group3-18">
                            <div className="rectangle-163-18"></div>
                            <div className="ellipse-55-22"></div>
                            <div className="rectangle-164-22"></div>
                            <img className="polygon-8-22" src="/img/polygon-8@2x.svg" alt="Polygon 8" />
                          </div>
                        </div>
                      </Link>
                      <div className="transferir-19 balooda-regular-normal-cape-cod-20px">{transferir}</div>
                    </div>
                    <div className="flex-col-27">
                      <Group23 />
                      <div className="depositar-20 balooda-regular-normal-picton-blue-20px-4">{depositar1}</div>
                    </div>
                  </div>
                </div>
                <div className="overlap-group11-11">
                  <div className="rectangle-60-5"></div>
                  <div className="carto-de-crdito-5 balooda-regular-normal-white-32px">{cartoDeCrdito}</div>
                  <Link to="/frame-28">
                    <p className="fatura-atual-5 balooda2-medium-white-16px">{faturaAtual}</p>
                  </Link>
                  <div className="text-22 balooda2-medium-white-16px">{text22}</div>
                  <div className="nome-do-usuario-12 balooda2-medium-white-16px">{nomeDoUsuario}</div>
                  <div className="limite-disponvel-de-r178010-2 balooda2-medium-white-16px">
                    {limiteDisponvelDeR178010}
                  </div>
                  <img className="x-2" src="/img/----@2x.svg" alt="****" />
                  <Link to="/frame-24">
                    <img className="vector-17-5" src="/img/vector-17@2x.svg" alt="Vector 17" />
                  </Link>
                  <img className="rectangle-70-5" src={rectangle70} alt="Rectangle 70" />
                </div>
              </div>
              <div className="overlap-group-container-42">
                <div className="overlap-group3-19">
                  <div className="depositar-21 balooda2-normal-cape-cod-24px">{depositar2}</div>
                  <img className="line-12" src="/img/line-49@1x.svg" alt="Line 52" />
                  <img className="line-12" src="/img/line-49@1x.svg" alt="Line 65" />
                </div>
                <div className="overlap-group-61 balooda-regular-normal-cape-cod-56px">
                  <div className="qual-valor-voc-quer-3">{qualValorVocQuer}</div>
                  <div className="depositar-22">{depositar3}</div>
                </div>
                <div className="overlap-group2-21">
                  <div className="price-14 balooda-regular-normal-cape-cod-56px">{price2}</div>
                  <img className="line-20-9" src="/img/line-20@2x.svg" alt="Line 20" />
                </div>
                <div className="overlap-group1-29">
                  <div className="depositar-23 balooda2-normal-white-24px">{depositar4}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame23;
