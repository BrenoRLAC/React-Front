import React from "react";
import Group87 from "../Group87";
import "./Group97.css";

function Group97(props) {
  const { className, group87Props } = props;

  return (
    <div className={`group-97 ${className || ""}`}>
      <Group87 className={group87Props.className} />
    </div>
  );
}

export default Group97;
