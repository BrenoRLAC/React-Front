import React from "react";
import { Link } from "react-router-dom";
import Group53 from "../Group53";
import Group24 from "../Group24";
import Group123 from "../Group123";
import Group87 from "../Group87";
import "./Frame21.css";

function Frame21(props) {
  const {
    olNomeDoUsuario,
    pginaInicial,
    configuraes,
    sair,
    rectangle210,
    skybank,
    conta,
    text2,
    depositar,
    atividade,
    transferir1,
    cartoDeCrdito,
    faturaAtual,
    text1,
    nomeDoUsuario,
    limiteDisponvelDe,
    rectangle70,
    text3,
    vocFezUmaTransferncia,
    transferir2,
    spanText1,
    spanText2,
    price,
    qualOValorDa,
    transferncia,
    transferir3,
    nomeCpfCnpj,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-21 screen">
        <div className="overlap-group9-1">
          <div className="overlap-group12">
            <Group53 />
            <div className="ol-nome-do-usuario-1 balooda-regular-normal-white-36px">{olNomeDoUsuario}</div>
          </div>
          <div className="overlap-group-container-6">
            <div className="overlap-group11">
              <div className="flex-row-2">
                <div className="rectangle-206"></div>
                <div className="overlap-group-6">
                  <div className="rectangle-46-1"></div>
                  <img className="line-9-1" src="/img/line-9-1@2x.svg" alt="Line 9" />
                  <div className="rectangle-47-1"></div>
                  <div className="rectangle-48-1"></div>
                  <img className="line-10-1" src="/img/line-10-1@2x.svg" alt="Line 10" />
                  <img className="line-11-1" src="/img/line-11-1@2x.svg" alt="Line 11" />
                </div>
                <div className="pgina-inicial-1 balooda-regular-normal-white-20px">{pginaInicial}</div>
              </div>
              <Link to="/frame-27">
                <div className="group-144">
                  <img className="config_icone-1" src="/img/config-icone-1@2x.svg" alt="Config_icone" />
                  <div className="configuraes-1 balooda-regular-normal-cape-cod-20px">{configuraes}</div>
                </div>
              </Link>
              <img className="line-59" src="/img/line-37@2x.svg" alt="Line 59" />
              <img className="line-58" src="/img/line-37@2x.svg" alt="Line 58" />
              <a href="javascript:ShowOverlay('frame-5', 'animate-appear');" className="align-self-flex-start">
                <div className="group-101">
                  <div className="overlap-group-7">
                    <div className="rectangle-180-1"></div>
                    <img className="line-32-1" src="/img/line-32@2x.svg" alt="Line 32" />
                    <img className="line-31-1" src="/img/line-31@2x.svg" alt="Line 31" />
                    <img className="vector-19-2" src="/img/vector-19@2x.svg" alt="Vector 19" />
                  </div>
                  <div className="sair-1 balooda-regular-normal-cape-cod-20px">{sair}</div>
                </div>
              </a>
              <img className="line-60" src="/img/line-37@2x.svg" alt="Line 60" />
              <div className="flex-row-3">
                <img className="rectangle-210" src={rectangle210} alt="Rectangle 210" />
                <img className="sky-bank-1" src={skybank} alt="SkyBank" />
              </div>
            </div>
            <div className="overlap-group10-1">
              <div className="overlap-group-container-7">
                <div className="overlap-group15">
                  <div className="overlap-group2-2">
                    <div className="flex-row-4">
                      <div className="group-container-3">
                        <div className="overlap-group3-2">
                          <div className="conta balooda2-normal-cape-cod-36px">{conta}</div>
                          <div className="text-2 balooda-regular-normal-cape-cod-56px">{text2}</div>
                        </div>
                        <Group24 />
                      </div>
                      <div className="group-23">
                        <div className="overlap-group-5">
                          <div className="rectangle-161"></div>
                          <div className="ellipse-54"></div>
                          <div className="rectangle-162"></div>
                          <img className="polygon-7" src="/img/polygon-7@2x.svg" alt="Polygon 7" />
                        </div>
                      </div>
                    </div>
                    <div className="depositar balooda-regular-normal-cape-cod-20px">{depositar}</div>
                  </div>
                  <img className="line-61" src="/img/line-61@1x.svg" alt="Line 61" />
                  <Link to="/frame-19">
                    <div className="group-102">
                      <div className="overlap-group4-3">
                        <img className="ellipse-13" src="/img/ellipse-13@2x.svg" alt="Ellipse 13" />
                        <img className="line-5" src="/img/line-5@2x.svg" alt="Line 5" />
                        <img className="line-7" src="/img/line-7@2x.svg" alt="Line 7" />
                        <img className="line-8" src="/img/line-8@2x.svg" alt="Line 8" />
                        <img className="line-6" src="/img/line-6@2x.svg" alt="Line 6" />
                      </div>
                    </div>
                  </Link>
                  <div className="atividade balooda-regular-normal-cape-cod-20px">{atividade}</div>
                  <div className="transferir balooda-regular-normal-picton-blue-20px-2">{transferir1}</div>
                  <Link to="/frame-26">
                    <div className="group-122">
                      <div className="overlap-group-5">
                        <div className="rectangle-161"></div>
                        <div className="ellipse-54"></div>
                        <div className="rectangle-162"></div>
                        <img className="polygon-7" src="/img/polygon-7-1@2x.svg" alt="Polygon 7" />
                      </div>
                    </div>
                  </Link>
                  <Group123 />
                  <Link to="/frame-16">
                    <div className="group-124">
                      <Group87 />
                    </div>
                  </Link>
                </div>
                <div className="overlap-group14">
                  <div className="overlap-group1-3">
                    <div className="rectangle-60"></div>
                    <div className="carto-de-crdito balooda-regular-normal-white-32px">{cartoDeCrdito}</div>
                    <Link to="/frame-30">
                      <p className="fatura-atual balooda2-medium-white-16px">{faturaAtual}</p>
                    </Link>
                    <div className="text-1 balooda2-medium-white-16px">{text1}</div>
                    <div className="nome-do-usuario-1 balooda2-medium-white-16px">{nomeDoUsuario}</div>
                    <p className="limite-disponvel-de balooda2-medium-white-16px">{limiteDisponvelDe}</p>
                    <Link to="/frame-22">
                      <img className="vector-17" src="/img/vector-17@2x.svg" alt="Vector 17" />
                    </Link>
                    <img className="rectangle-70" src={rectangle70} alt="Rectangle 70" />
                  </div>
                  <div className="text-3 balooda2-bold-white-36px">{text3}</div>
                </div>
              </div>
              <div className="overlap-group13">
                <div className="voc-fez-uma-transferncia balooda2-normal-cape-cod-28px">{vocFezUmaTransferncia}</div>
                <div className="rectangle-202"></div>
                <div className="transferir-1 balooda2-normal-cape-cod-24px">{transferir2}</div>
                <p className="saldo-disponvel-em-conta balooda2-normal-cape-cod-24px">
                  <span className="balooda2-normal-cape-cod-24px">{spanText1}</span>
                  <span className="balooda2-bold-cape-cod-24px">{spanText2}</span>
                </p>
                <div className="price balooda-regular-normal-cape-cod-56px">{price}</div>
                <div className="overlap-group7-2 balooda-regular-normal-cape-cod-56px">
                  <p className="qual-o-valor-da">{qualOValorDa}</p>
                  <div className="transferncia">{transferncia}</div>
                </div>
                <div className="overlap-group8-2">
                  <div className="transferir-2 balooda2-normal-white-24px">{transferir3}</div>
                </div>
                <img className="line-66" src="/img/line-66@2x.svg" alt="Line 66" />
                <img className="line-67" src="/img/line-66@2x.svg" alt="Line 67" />
                <div className="nome-cpfcnpj balooda2-normal-pink-swan-36px">{nomeCpfCnpj}</div>
                <img className="line-65" src="/img/line-65@1x.svg" alt="Line 65" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Frame21;
