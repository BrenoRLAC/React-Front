import "./App.css";
import React from "react";
import { Switch, BrowserRouter as Router, Route } from "react-router-dom";
import Frame1 from "./components/Frame1";
import Frame10 from "./components/Frame10";
import Frame27 from "./components/Frame27";
import Frame4 from "./components/Frame4";
import Frame5 from "./components/Frame5";
import Frame21 from "./components/Frame21";
import Frame26 from "./components/Frame26";
import Frame18 from "./components/Frame18";
import Frame24 from "./components/Frame24";
import Frame22 from "./components/Frame22";
import Frame20 from "./components/Frame20";
import Frame17 from "./components/Frame17";
import Frame25 from "./components/Frame25";
import Frame8 from "./components/Frame8";
import Frame34 from "./components/Frame34";
import Frame31 from "./components/Frame31";
import Frame35 from "./components/Frame35";
import Frame2 from "./components/Frame2";
import Frame36 from "./components/Frame36";
import Frame37 from "./components/Frame37";
import Frame16 from "./components/Frame16";
import Frame15 from "./components/Frame15";
import Frame19 from "./components/Frame19";
import Frame32 from "./components/Frame32";
import Frame23 from "./components/Frame23";
import Frame9 from "./components/Frame9";
import Frame28 from "./components/Frame28";
import Frame3 from "./components/Frame3";
import Frame30 from "./components/Frame30";
import Frame33 from "./components/Frame33";

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/frame-1">
          <Frame1 {...frame1Data} />
        </Route>
        <Route path="/frame-10">
          <Frame10>estamos preparando tudo para você</Frame10>
        </Route>
        <Route path="/frame-27">
          <Frame27 {...frame27Data} />
        </Route>
        <Route path="/frame-4">
          <Frame4 {...frame4Data} />
        </Route>
        <Route path="/frame-5">
          <Frame5 desejaRealmenteDesconectar="Deseja realmente desconectar?" no="Não" sim="Sim" />
        </Route>
        <Route path="/frame-21">
          <Frame21 {...frame21Data} />
        </Route>
        <Route path="/frame-26">
          <Frame26 {...frame26Data} />
        </Route>
        <Route path="/:path(|frame-18)">
          <Frame18 rectangle191="/img/rectangle-191@1x.png" skybank="/img/skybank-1@1x.png" />
        </Route>
        <Route path="/frame-24">
          <Frame24 {...frame24Data} />
        </Route>
        <Route path="/frame-22">
          <Frame22 {...frame22Data} />
        </Route>
        <Route path="/frame-20">
          <Frame20 {...frame20Data} />
        </Route>
        <Route path="/frame-17">
          <Frame17 {...frame17Data} />
        </Route>
        <Route path="/frame-25">
          <Frame25 {...frame25Data} />
        </Route>
        <Route path="/frame-8">
          <Frame8>Bem vindo (a) ao SkyBank</Frame8>
        </Route>
        <Route path="/frame-34">
          <Frame34 cep="CEP" salvar="Salvar" />
        </Route>
        <Route path="/frame-31">
          <Frame31 fatura="Fatura" price="R$ 19,90" pagarFatura="Pagar fatura" />
        </Route>
        <Route path="/frame-35">
          <Frame35 endereo="Endereço" ruaAvenida="(Rua / Avenida)" salvar="Salvar" />
        </Route>
        <Route path="/frame-2">
          <Frame2 {...frame2Data} />
        </Route>
        <Route path="/frame-36">
          <Frame36 nmero="Número" />
        </Route>
        <Route path="/frame-37">
          <Frame37 complemento="Complemento" group169Props={frame371Data.group169Props} />
        </Route>
        <Route path="/frame-38">
          <Frame37 complemento="Bairro" group169Props={frame372Data.group169Props} />
        </Route>
        <Route path="/frame-16">
          <Frame16 {...frame16Data} />
        </Route>
        <Route path="/frame-15">
          <Frame15 {...frame15Data} />
        </Route>
        <Route path="/frame-19">
          <Frame19 {...frame19Data} />
        </Route>
        <Route path="/frame-32">
          <Frame32 {...frame32Data} />
        </Route>
        <Route path="/frame-23">
          <Frame23 {...frame23Data} />
        </Route>
        <Route path="/frame-9">
          <Frame9 />
        </Route>
        <Route path="/frame-28">
          <Frame28 {...frame28Data} />
        </Route>
        <Route path="/frame-3">
          <Frame3 {...frame3Data} />
        </Route>
        <Route path="/frame-30">
          <Frame30 {...frame30Data} />
        </Route>
        <Route path="/frame-33">
          <Frame33 ruaAvenida="Rua/Avenida" polygon11="" polygon12="" />
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
const component1Data = {
    children: "Entrar",
};

const frame1Data = {
    investindoComASkybankOCuOLimite: "/img/investindo-com-a-skybank--o-c-u---o-limite@1x.png",
    group170: "/img/group-170@1x.png",
    overlapGroup1: "/img/rectangle-75@1x.png",
    entrar: "Entrar",
    cpf: "CPF",
    senha: "Senha",
    noTemUmaConta: "Não tem uma conta?",
    cadastreSe1: "cadastre-se",
    aindaNoTemUmaConta: "Ainda não tem uma conta?",
    cadastreSe2: "Cadastre-se",
    component1Props: component1Data,
};

const frame27Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle190: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    nomeDoUsuario1: "Nome do usuario",
    nomeDoUsuario2: "Nome do usuario",
    seusDados1: "Seus dados",
    seusDados2: "Seus dados",
    gerencieSeusDadosPessoais: "Gerencie seus dados pessoais.",
    group174: "/img/group-174@1x.png",
    seuCarto: "Seu cartão",
    gerencieSeuCarto: "Gerencie seu cartão.",
    group175: "/img/group-175@1x.png",
    endereo: "Endereço",
    altereSeuEndereoOuAdicioneOutro: "Altere seu endereço ou adicione outro.",
};

const frame21Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle210: "/img/rectangle-210@1x.png",
    skybank: "/img/skybank@1x.png",
    conta: "Conta",
    text2: "****",
    depositar: "Depositar",
    atividade: "Atividade",
    transferir1: "Transferir",
    cartoDeCrdito: "Cartão de crédito",
    faturaAtual: "Fatura atual   >",
    text1: "**** 1234",
    nomeDoUsuario: "NOME DO USUARIO",
    limiteDisponvelDe: "Limite disponível de  ****",
    rectangle70: "/img/rectangle-70@2x.png",
    text3: "****",
    vocFezUmaTransferncia: "Você fez uma transferência",
    transferir2: "Transferir",
    spanText1: "Saldo disponível em conta ",
    spanText2: "****",
    price: "R$0,00",
    qualOValorDa: "Qual é o valor da",
    transferncia: "transferência?",
    transferir3: "Transferir",
    nomeCpfCnpj: "Nome, CPF/CNPJ",
};

const frame26Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle210: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    conta: "Conta",
    text5: "****",
    depositar1: "Depositar",
    atividade: "Atividade",
    transferir: "Transferir",
    group122: "/img/group-122@1x.png",
    cartoDeCrdito: "Cartão de crédito",
    faturaAtual: "Fatura atual   >",
    text4: "**** 1234",
    nomeDoUsuario: "NOME DO USUARIO",
    limiteDisponvelDe: "Limite disponível de  ****",
    rectangle70: "/img/rectangle-70@2x.png",
    text6: "****",
    vocFezUmaTransferncia: "Você fez uma transferência",
    depositar2: "Depositar",
    qualValorVocQuer: "Qual valor você quer",
    depositar3: "depositar?",
    price: "R$0,00",
    depositar4: "Depositar",
};

const frame24Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle172: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    conta: "Conta",
    price1: "R$2.500,00",
    atividade: "Atividade",
    transferir: "Transferir",
    depositar1: "Depositar",
    nomeDoUsuario: "Nome do Usuario",
    place: "Nome",
    address: "4444 3333 2222 1234",
    nmero: "Número",
    copiar: "Copiar",
    text7: "00/00",
    validade: "Validade",
    number: "111",
    cvc: "CVC",
    depositar2: "Depositar",
    qualValorVocQuer: "Qual valor você quer",
    depositar3: "depositar?",
    price2: "R$0,00",
    depositar4: "Depositar",
};

const frame22Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle199: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    conta: "Conta",
    text8: "****",
    depositar: "Depositar",
    group57: "/img/group-57@1x.png",
    atividade: "Atividade",
    transferir1: "Transferir",
    nomeDoUsuario: "Nome do Usuario",
    place: "Nome",
    address: "4444 3333 2222 1234",
    nmero: "Número",
    copiar: "Copiar",
    text9: "00/00",
    validade: "Validade",
    number: "111",
    cvc: "CVC",
    transferir2: "Transferir",
    qualOValorDa: "Qual é o valor da",
    transferncia: "transferência?",
    spanText1: "Saldo disponível em conta ",
    spanText2: "****",
    price: "R$0,00",
    nomeCpfCnpj: "Nome, CPF/CNPJ",
    transferir3: "Transferir",
};

const group244Data = {
    className: "group-24-3",
};

const frame20Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle190: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    depositar: "Depositar",
    conta: "Conta",
    price1: "R$2.500,00",
    group21: "/img/group-21@1x.png",
    atividade: "Atividade",
    transferir1: "Transferir",
    nomeDoUsuario: "Nome do Usuario",
    place: "Nome",
    address: "4444 3333 2222 1234",
    nmero: "Número",
    iconCopy: "/img/group-173@1x.png",
    copiar: "Copiar",
    vector18: "/img/vector-18@1x.png",
    text10: "00/00",
    validade: "Validade",
    number: "111",
    cvc: "CVC",
    suaAtividade: "Sua atividade",
    vocFezUmaTransferncia: "Você fez uma transferência",
    vocRecebeuUmaTransferncia: "Você recebeu uma transferência",
    r20000: "-R$ 200,00",
    r15000: "+R$ 150,00",
    hoje: "hoje",
    ontem: "ontem",
    transferir2: "Transferir",
    spanText1: "Saldo disponível em conta ",
    spanText2: "R$ 2.500,00",
    price2: "R$0,00",
    qualOValorDa: "Qual é o valor da",
    transferncia: "transferência?",
    transferir3: "Transferir",
    nomeCpfCnpj: "Nome, CPF/CNPJ",
    group24Props: group244Data,
};

const group245Data = {
    className: "group-24-4",
};

const group876Data = {
    className: "group-87-5",
};

const group971Data = {
    group87Props: group876Data,
};

const group852Data = {
    className: "group-94",
};

const group842Data = {
    className: "group-93",
};

const frame17Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle199: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    conta: "Conta",
    text11: "****",
    transferir: "Transferir",
    depositar: "Depositar",
    atividade: "Atividade",
    nomeDoUsuario: "Nome do Usuario",
    place: "Nome",
    address: "4444 3333 2222 1234",
    nmero: "Número",
    copiar: "Copiar",
    text12: "00/00",
    validade: "Validade",
    number: "111",
    cvc: "CVC",
    suaAtividade: "Sua atividade",
    vocFezUmaTransferncia: "Você fez uma transferência",
    r20000: "-R$ 200,00",
    hoje: "hoje",
    vocRecebeuUmaTransferncia: "Você recebeu uma transferência",
    r15000: "+R$ 150,00",
    ontem: "ontem",
    group24Props: group245Data,
    group97Props: group971Data,
    group85Props: group852Data,
    group84Props: group842Data,
};

const group232Data = {
    className: "group-126",
};

const frame25Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    group53: "/img/group-53@1x.png",
    rectangle199: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    conta: "Conta",
    text13: "****",
    depositar1: "Depositar",
    atividade: "Atividade",
    transferir: "Transferir",
    nomeDoUsuario: "Nome do Usuario",
    place: "Nome",
    address: "4444 3333 2222 1234",
    nmero: "Número",
    copiar: "Copiar",
    text14: "00/00",
    validade: "Validade",
    number: "111",
    cvc: "CVC",
    depositar2: "Depositar",
    qualValorVocQuer: "Qual valor você quer",
    depositar3: "depositar?",
    price: "R$0,00",
    depositar4: "Depositar",
    group23Props: group232Data,
};

const group878Data = {
    className: "group-87-7",
};

const group972Data = {
    className: "group-89-1",
    group87Props: group878Data,
};

const group853Data = {
    className: "group-70",
};

const group843Data = {
    className: "group-69",
};

const frame2Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle172: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    conta: "Conta",
    price: "R$2.500,00",
    atividade: "Atividade",
    transferir: "Transferir",
    depositar: "Depositar",
    cartoDeCrdito: "Cartão de crédito",
    faturaAtual: "Fatura atual   >",
    text15: "**** 1234",
    nomeDoUsuario: "NOME DO USUARIO",
    limiteDisponvelDeR178010: "Limite disponível de R$1.780,10",
    rectangle70: "/img/rectangle-70@2x.png",
    suaAtividade: "Sua atividade",
    vocFezUmaTransferncia: "Você fez uma transferência",
    r20000: "-R$ 200,00",
    hoje: "hoje",
    vocRecebeuUmaTransferncia: "Você recebeu uma transferência",
    r15000: "+R$ 150,00",
    ontem: "ontem",
    group97Props: group972Data,
    group85Props: group853Data,
    group84Props: group843Data,
};

const group1692Data = {
    className: "group-169-1",
};

const frame371Data = {
    group169Props: group1692Data,
};

const group1693Data = {
    className: "group-169-2",
};

const frame372Data = {
    group169Props: group1693Data,
};

const group247Data = {
    className: "group-24-6",
};

const group854Data = {
    className: "group-99-1",
};

const group844Data = {
    className: "group-98-1",
};

const frame16Data = {
    group53: "/img/group-53-1@1x.png",
    olNomeDoUsuario: "Olá, Nome do usuario",
    iconHome: "/img/paginal-inicial-icone@1x.png",
    pginaInicial: "Página Inicial",
    iconSettings: "/img/config-icone@1x.png",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle190: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    conta: "Conta",
    text17: "****",
    transferir: "Transferir",
    depositar: "Depositar",
    atividade: "Atividade",
    cartoDeCrdito: "Cartão de crédito",
    faturaAtual: "Fatura atual   >",
    text16: "**** 1234",
    nomeDoUsuario: "NOME DO USUARIO",
    limiteDisponvelDe: "Limite disponível de  ****",
    rectangle70: "/img/rectangle-70@2x.png",
    text18: "****",
    suaAtividade: "Sua atividade",
    vocFezUmaTransferncia: "Você fez uma transferência",
    r20000: "-R$ 200,00",
    hoje: "hoje",
    vocRecebeuUmaTransferncia: "Você recebeu uma transferência",
    r15000: "+R$ 150,00",
    ontem: "ontem",
    group24Props: group247Data,
    group85Props: group854Data,
    group84Props: group844Data,
};

const group248Data = {
    className: "group-24-7",
};

const group855Data = {
    className: "group-94-1",
};

const group845Data = {
    className: "group-93-1",
};

const frame15Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle190: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    transferir: "Transferir",
    depositar: "Depositar",
    conta: "Conta",
    price: "R$2.500,00",
    atividade: "Atividade",
    group92: "/img/group-92@1x.png",
    group93: "/img/group-93@1x.png",
    nomeDoUsuario: "Nome do Usuario",
    place: "Nome",
    address: "4444 3333 2222 1234",
    nmero: "Número",
    copiar: "Copiar",
    text19: "00/00",
    validade: "Validade",
    number: "111",
    cvc: "CVC",
    suaAtividade: "Sua atividade",
    vocFezUmaTransferncia: "Você fez uma transferência",
    r20000: "-R$ 200,00",
    hoje: "hoje",
    vocRecebeuUmaTransferncia: "Você recebeu uma transferência",
    r15000: "+R$ 150,00",
    ontem: "ontem",
    group24Props: group248Data,
    group85Props: group855Data,
    group84Props: group845Data,
};

const frame19Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle172: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    conta: "Conta",
    price1: "R$2.500,00",
    group89: "/img/group-89@1x.png",
    atividade: "Atividade",
    group88: "/img/group-88@1x.png",
    transferir1: "Transferir",
    group23: "/img/group-23@1x.png",
    depositar: "Depositar",
    cartoDeCrdito: "Cartão de crédito",
    faturaAtual: "Fatura atual   >",
    text20: "**** 1234",
    nomeDoUsuario: "NOME DO USUARIO",
    limiteDisponvelDeR178010: "Limite disponível de R$1.780,10",
    rectangle70: "/img/rectangle-70@2x.png",
    transferir2: "Transferir",
    qualOValorDa: "Qual é o valor da",
    transferncia: "transferência?",
    nomeCpfCnpj: "Nome, CPF/CNPJ",
    spanText1: "Saldo disponível em conta ",
    spanText2: "R$ 2.500,00",
    price2: "R$0,00",
    transferir3: "Transferir",
};

const group5312Data = {
    className: "group-53-1",
};

const frame32Data = {
    configuraes: "Configurações",
    pginaInicial: "Página Inicial",
    sair: "Sair",
    rectangle190: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    cep: "CEP",
    text21: "00000-000",
    nomeDaRuaAvenida: "Nome da rua/avenida",
    number: "000",
    endereo1: "Endereço",
    nmero: "Número",
    complemento: "Complemento",
    opcional: "(Opcional)",
    nomeDoBairro: "Nome do bairro",
    sala0: "Sala 0",
    bairro: "Bairro",
    endereo2: "Endereço",
    altereSeuEndereoOuAdicioneOutro: "Altere seu endereço ou adicione outro",
    voltar: "Voltar",
    olNomeDoUsuario: "Olá, Nome do usuario",
    group53Props: group5312Data,
};

const frame23Data = {
    olNomeDoUsuario: "Olá, Nome do usuario",
    pginaInicial: "Página Inicial",
    configuraes: "Configurações",
    sair: "Sair",
    rectangle172: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    conta: "Conta",
    price1: "R$2.500,00",
    atividade: "Atividade",
    transferir: "Transferir",
    depositar1: "Depositar",
    cartoDeCrdito: "Cartão de crédito",
    faturaAtual: "Fatura atual   >",
    text22: "**** 1234",
    nomeDoUsuario: "NOME DO USUARIO",
    limiteDisponvelDeR178010: "Limite disponível de R$1.780,10",
    rectangle70: "/img/rectangle-70-5@1x.png",
    depositar2: "Depositar",
    qualValorVocQuer: "Qual valor você quer",
    depositar3: "depositar?",
    price2: "R$0,00",
    depositar4: "Depositar",
};

const group5314Data = {
    className: "group-53-2",
};

const group1392Data = {
    className: "group-139-1",
};

const frame28Data = {
    configuraes: "Configurações",
    pginaInicial: "Página Inicial",
    olNomeDoUsuario: "Olá, Nome do usuario",
    sair: "Sair",
    rectangle190: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    place: "Nome",
    nomeDoUsuario: "Nome do usuario",
    address: "4444 3333 2222 1234",
    text23: "00/00",
    number: "111",
    price: "R$19,90",
    nmero: "Número",
    validade: "Validade",
    cvv: "CVV",
    seuCarto: "Seu cartão",
    gerencieSeuCarto: "Gerencie seu cartão",
    voltar: "Voltar",
    fatura: "Fatura",
    group53Props: group5314Data,
    group139Props: group1392Data,
};

const group1393Data = {
    className: "group-139-2",
};

const group1602Data = {
    className: "group-162-1",
};

const group5315Data = {
    className: "group-53-3",
};

const frame30Data = {
    configuraes: "Configurações",
    iconSettings: "/img/config-icone-1@1x.png",
    iconHome: "/img/paginal-inicial-icone-1@1x.png",
    pginaInicial: "Página Inicial",
    sair: "Sair",
    rectangle190: "/img/rectangle-190@2x.png",
    skybank: "SkyBank",
    nomeCompleto: "Nome completo",
    nomeDoUsuario: "Nome do usuario",
    nomeEmailCom: "nome@email.com",
    phone: "123.456.789-10",
    text24: "********",
    nmero: "Número",
    cpf: "CPF",
    senha: "Senha",
    group59: "/img/group-59@1x.png",
    seusDados: "Seus dados",
    gerencieSeusDadosPessoais: "Gerencie seus dados pessoais.",
    voltar: "Voltar",
    olNomeDoUsuario: "Olá, Nome do usuario",
    group139Props: group1393Data,
    group160Props: group1602Data,
    group53Props: group5315Data,
};

const frame4Data = {
    endereo1: "Endereço",
    endereo2: "Endereço",
    nmero: "Número",
    complemento: "Complemento",
    place: "Cidade",
    uf: "UF",
    bairro: "Bairro",
    cep: "CEP",
    voltar: "Voltar",
    group27: "/img/group-27@1x.png",
    i: "i",
};

const frame3Data = {
    cadastrar: "Cadastrar",
    nomeCompleto: "Nome completo",
    senha: "Senha",
    spanText1: "Data de Nascimento ",
    spanText2: "(DD/MM/AAAA)",
    eMail: "E-mail",
    cpf: "CPF",
    avanar: "Avançar",
    voltar: "Voltar",
};

